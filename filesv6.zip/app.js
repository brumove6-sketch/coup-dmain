// ============================================================
        // CONFIG — REMPLACE CES VALEURS AVANT MISE EN PROD
        // ============================================================
        // Stripe : clé publique dans dashboard.stripe.com > Developers > API keys
        const STRIPE_PUBLISHABLE_KEY = 'pk_live_REMPLACE_CLE_STRIPE_PUBLIQUE';
        // Crée des Payment Links dans Stripe Dashboard (Products > Payment Links)
        // Un lien par montant, ajoute ?prefilled_email=EMAIL pour pré-remplir
        const STRIPE_PAYMENT_LINKS = {
            15:  'https://buy.stripe.com/REMPLACE_LIEN_15EUR',
            25:  'https://buy.stripe.com/REMPLACE_LIEN_25EUR',
            275: 'https://buy.stripe.com/REMPLACE_LIEN_275EUR',
            default: 'https://buy.stripe.com/REMPLACE_LIEN_DEFAULT'
        };

        // EmailJS : emailjs.com > Add Service (Gmail/SMTP) > récupère les IDs
        const EMAILJS_SERVICE_ID  = 'service_REMPLACE';
        const EMAILJS_TEMPLATE_ID = 'template_REMPLACE';
        const EMAILJS_PUBLIC_KEY  = 'REMPLACE_PUBLIC_KEY';
        // Ton email de réception des leads
        const LEADS_EMAIL = 'contact@agpgroup.be';

        // URL de ton projet Vercel (sans slash final)
        // Ex: 'https://coupmain-webhook.vercel.app'
        // Ton URL Netlify — Ex: https://coupmain.netlify.app
        // Netlify redirige /api/* vers Vercel via netlify.toml
        // En prod: remplace par ton vrai sous-domaine Netlify
        const NETLIFY_BASE = window.location.origin.includes('localhost') || window.location.protocol === 'file:'
            ? 'https://REMPLACE_PAR_TON_SITE.netlify.app'  // fallback local
            : window.location.origin;                        // auto en prod Netlify
        const VERCEL_API_BASE = NETLIFY_BASE;  // les /api/* sont proxifiés par netlify.toml

        // ── NETTOYEUR AMANA — Purge dataStore côté client toutes les 60s ──
        // Côté serveur : ajouter une tâche Cron sur /tmp/uploads/ (voir instructions Vercel)
        // Côté client : efface les données sensibles en session si inactif > 60s
        let _amanaTimer = null;
        let _lastActivity = Date.now();

        function resetAmanaTimer() {
            _lastActivity = Date.now();
            clearTimeout(_amanaTimer);
            _amanaTimer = setTimeout(() => {
                // Purge sélective — conserve rgpd_consent et pays, efface données personnelles
                const keep = { rgpd_consent: dataStore.rgpd_consent, country_code: dataStore.country_code, country_name: dataStore.country_name, lang: dataStore.lang };
                Object.keys(dataStore).forEach(k => delete dataStore[k]);
                Object.assign(dataStore, keep);
                console.log('[AMANA] Données personnelles purgées — session expirée (60s inactivité)');
            }, 60000);
        }

        document.addEventListener('click',    resetAmanaTimer, { passive: true });
        document.addEventListener('keydown',  resetAmanaTimer, { passive: true });
        document.addEventListener('touchstart', resetAmanaTimer, { passive: true });
        resetAmanaTimer(); // Démarre le timer dès le chargement
        // ── FIN NETTOYEUR AMANA ──────────────────────────────────────────────

        document.addEventListener('DOMContentLoaded', function() {
            // Init EmailJS
            if (typeof emailjs !== 'undefined') emailjs.init(EMAILJS_PUBLIC_KEY);

            // Restaure la langue si déjà visitée
            try {
                const saved = localStorage.getItem('cdm_lang');
                if (saved && ['FR','NL','EN'].includes(saved)) switchLang(saved);
            } catch(e) {}

            // Filet de sécurité : addEventListener sur boutons langue (robuste Netlify)
            try {
                ['fr','nl','en'].forEach(function(l) {
                    var btn = document.getElementById('lang-' + l);
                    if (btn) {
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            if (typeof switchLang === 'function') switchLang(l.toUpperCase());
                        });
                    }
                });

                // Filet de sécurité : boutons pays dans la modal
                document.querySelectorAll('[data-country]').forEach(function(btn) {
                    btn.addEventListener('click', function(e) {
                        var code = this.getAttribute('data-country');
                        if (code && typeof acceptAndStart === 'function') {
                            var name = (typeof getCountryName === 'function') ? getCountryName(code) : code;
                            acceptAndStart(code, name);
                        }
                    });
                });
            } catch(err) { console.warn('[DOMContentLoaded listeners]', err); }
        });
        // ============================================================

// --- 1. SYSTEME DE PARTICULES ---
        const heroBg = document.querySelector('.hero-bg');
        if (heroBg) {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            heroBg.appendChild(canvas);
            let particles = [];
            const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
            window.addEventListener('resize', resize); resize();

            class Particle {
                constructor() { this.reset(); }
                reset() {
                    this.x = Math.random() * canvas.width;
                    this.y = Math.random() * canvas.height;
                    this.size = Math.random() * 1.5;
                    this.speedX = Math.random() * 0.4 - 0.2;
                    this.speedY = Math.random() * 0.4 - 0.2;
                }
                update() {
                    this.x += this.speedX; this.y += this.speedY;
                    if (this.x > canvas.width || this.x < 0 || this.y > canvas.height || this.y < 0) this.reset();
                }
                draw() {
                    ctx.fillStyle = 'rgba(0, 255, 102, 0.15)';
                    ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill();
                }
            }
            for (let i = 0; i < 80; i++) particles.push(new Particle());
            const animate = () => {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                particles.forEach(p => { p.update(); p.draw(); });
                requestAnimationFrame(animate);
            };
            animate();
        }

        // --- 2. AUDIO ENGINE ---
        let audioCtx;
        let ambientOsc;
        let ambientGain;
        let isAudioPlaying = false;

        function initAudio() {
            if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }

        function playBeep(freq = 440, duration = 0.05) {
            initAudio();
            if (!isAudioPlaying) return;
            try {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain); gain.connect(audioCtx.destination);
                osc.frequency.value = freq;
                gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
                osc.start(); osc.stop(audioCtx.currentTime + duration);
            } catch(e) {}
        }

        function startAmbient() {
            initAudio();
            if (ambientOsc) return;
            ambientGain = audioCtx.createGain();
            ambientGain.gain.setValueAtTime(0, audioCtx.currentTime);
            ambientGain.gain.exponentialRampToValueAtTime(0.03, audioCtx.currentTime + 2); // Fade In
            ambientGain.connect(audioCtx.destination);

            ambientOsc = audioCtx.createOscillator();
            ambientOsc.type = 'sine';
            ambientOsc.frequency.setValueAtTime(55, audioCtx.currentTime); // Deep A
            ambientOsc.connect(ambientGain);
            ambientOsc.start();
            isAudioPlaying = true;
            document.getElementById('audio-icon').innerText = "🔊";
        }

        function stopAmbient() {
            if (ambientOsc) {
                ambientOsc.stop();
                ambientOsc = null;
            }
            isAudioPlaying = false;
            document.getElementById('audio-icon').innerText = "🔈";
        }

        function toggleAudio() {
            if (isAudioPlaying) stopAmbient();
            else startAmbient();
        }

        // --- 3. DATA & CHATBOT ---
        const matrixData = {
            "Artisanat": {
                "Plomberie & Chauffage": {
                    "Fuites / Tuyauterie": ["Rupture canalisation", "Fuite sous évier/baignoire", "Débouchage urgent"],
                    "Sanitaires / Salles de bain": ["Installation complète SDB", "Remplacement WC/Douche", "Robinetterie défectueuse"],
                    "Chauffe-eau / Solaire": ["Panne totale eau chaude", "Entretien chaudière", "Installation Boiler/Solaire"]
                },
                "Électricité & Domotique": {
                    "Mise aux normes": ["Rénovation complète", "Mise à la terre", "Diagnostic conformité"],
                    "Panneaux solaires": ["Installation nouvelle", "Dépannage onduleur", "Nettoyage/Maintenance"],
                    "Tableaux / Connectivité": ["Remplacement tableau", "Tirage de câbles/Prises", "Coupure de courant partielle"]
                },
                "Rénovation Intérieure": {
                    "Peinture / Enduits": ["Peinture complète", "Réparation murs/plafonds", "Façades"],
                    "Pose de sols / Parquet": ["Parquet massif/stratifié", "Carrelage", "Ragréage"],
                    "Cloisons / Placo": ["Création de pièces", "Faux plafonds", "Isolation phonique"]
                },
                "Maçonnerie & Gros Œuvre": {
                    "Murs / Fondations": ["Mur porteur (IPN)", "Fondations/Dalle", "Fissures structurelles"],
                    "Terrasses": ["Création dalle béton", "Pose carrelage extérieur", "Terrasse bois/composite"],
                    "Démolition": ["Démolition mur/cloison", "Évacuation gravats", "Ouverture de trémie"]
                },
                "Menuiserie & Ouvertures": {
                    "Fenêtres / PVC / Alu": ["Remplacement double vitrage", "Installation Châssis", "Réglage/Réparation"],
                    "Portes / Blindage": ["Porte d'entrée blindée", "Portes intérieures", "Serrure haute sécurité"],
                    "Cuisines sur mesure": ["Conception complète", "Pose de meubles", "Plan de travail"]
                },
                "Toiture & Isolation": {
                    "Étanchéité / Tuiles": ["Fuite toit (Urgence)", "Remplacement de tuiles", "Rénovation complète"],
                    "Isolation combles": ["Laine de roche/verre", "Isolation par l'extérieur", "Isolation plancher"],
                    "Nettoyage / Traitement": ["Démoussage toiture", "Traitement hydrofuge", "Zinguerie/Gouttières"]
                },
                "Serrurerie & Sécurité": {
                    "Ouverture porte / Dépannage": ["Porte claquée/fermée", "Clé cassée dans serrure", "Changement cylindre"],
                    "Alarmes / Caméras": ["Installation vidéosurveillance", "Alarme sans fil", "Contrôle d'accès"],
                    "Blindage": ["Blindage de porte existante", "Cornières anti-pince", "Grilles de défense"]
                }
            },
            "Énergies Renouvelables": {
                "Solaire Photovoltaïque": {
                    "Installation complète": ["Système < 5kWp", "Système > 10kWp", "Batteries de stockage"],
                    "Maintenance & Onduleur": ["Remplacement onduleur", "Nettoyage panneaux", "Monitoring IA"],
                    "Optimisation": ["Bornes de recharge", "Gestion intelligente"]
                },
                "Pompes à Chaleur (PAC)": {
                    "Air-Eau / Air-Air": ["Installation Chauffage", "Climatisation Réversible", "Entretien"],
                    "Géothermie": ["Forage vertical", "Captage horizontal"],
                    "Hybride": ["Relève de chaudière", "Système combiné"]
                },
                "Audit & Performance": {
                    "Audit Logement Wallonie": ["Audit obligatoire primes", "Certificat PEB"],
                    "Étude Photovoltaïque": ["Rentabilité 10 ans", "Simulation ombrage"],
                    "Scan Thermique": ["Détection de fuites", "Isolation par drone"]
                }
            },
            "Location & Logistique": {
                "Transport & Petits Déménagements": {
                    "Retrait Magasin (IKEA, Brico...)": ["Course IKEA", "Course Brico / Hubo", "Course Hornbach", "Autre enseigne"],
                    "Évacuation Encombrants": ["Meubles usagés", "Électroménager", "Déchets verts / Jardin", "Déchets vers déchèterie"],
                    "Petit Déménagement": ["Studio / 1 pièce", "Camion avec chauffeur", "Aide à la manutention"],
                    "Livraison Express Pro": ["Matériaux de chantier", "Livraison palettes", "Transport sécurisé outillage"]
                },
                "Location de Benne & Déchets": {
                    "Gravats / Briquaillons": ["Benne 8m³", "Benne 14m³", "Sac à gravats (BigBag)"],
                    "Déchets Mixtes / Encombrants": ["Benne 14m³", "Benne 20m³", "Benne 30m³"],
                    "Déchets de Jardin": ["Benne 10m³", "Service de broyage"]
                },
                "Permis & Légal": {
                    "Occupation de voirie (25€)": ["Demande Standard", "Demande Urgente (24h)", "Signalisation incluse"],
                    "Attestation TVA 6%": ["Audit éligibilité", "Signature électronique"],
                    "Contre-Expertise": ["Sinistre Eau/Feu", "Litige Artisan"]
                }
            },
            "Automobile & Mobilité": {
                "Dépannage & Remorquage": {
                    "Panne sur route": ["Panne moteur / batterie", "Pneu crevé", "Panne de carburant"],
                    "Remorquage urgent": ["Véhicule accidenté", "VL vers garage", "Moto / Scooter"]
                },
                "Garage & Mécanique": {
                    "Révision & Entretien": ["Vidange complète", "Freins", "Courroie distribution"],
                    "Carrosserie": ["Débosselage / PDR", "Peinture partielle", "Remplacement pare-choc"],
                    "Diagnostic électronique": ["Lecture codes OBD", "Défaut témoin", "Mise à jour logiciel"]
                },
                "Assurance & Transfert": {
                    "Convoyage de véhicule": ["Livraison achat/vente", "Convoi longue distance", "Retour après sinistre"],
                    "Expertise sinistre": ["Contre-expertise assurance", "Estimation dommages", "Rapport contradictoire"]
                }
            }
        };

        const belgianCities = { "1000": "Bruxelles", "1050": "Ixelles", "4000": "Liège", "5000": "Namur", "6000": "Charleroi" };
        const chatWin = document.getElementById("chat-window");
        const msgEl = document.getElementById("chat-messages");
        const ctrlEl = document.getElementById("chat-controls");
        let dataStore = { cp: "" };
        let isDragging = false, startX, startY, initialLeft, initialTop;
        // DRAG & DROP LOGIC (Saisie globale)
        chatWin.addEventListener('mousedown', e => {
            if (chatWin.classList.contains('minimized')) return;
            // Ne pas dragger si on clique sur un bouton ou un select
            if (e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT' || e.target.closest('.ui-btn') || e.target.closest('.num-btn')) return;
            
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialLeft = chatWin.offsetLeft;
            initialTop = chatWin.offsetTop;
            document.addEventListener('mousemove', drag);
            document.addEventListener('mouseup', stopDrag);
            chatWin.style.transition = 'none';
        });

        function drag(e) {
            if (!isDragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            chatWin.style.left = `${initialLeft + dx}px`;
            chatWin.style.top = `${initialTop + dy}px`;
            chatWin.style.right = 'auto';
            chatWin.style.bottom = 'auto';
        }

        function stopDrag() {
            isDragging = false;
            document.removeEventListener('mousemove', drag);
            document.removeEventListener('mouseup', stopDrag);
            chatWin.style.transition = 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)';
        }

        function toggleChat(e) {
            // Reset complet pour éviter fond jaune résiduel
            const cw = document.getElementById('chat-window');
            if (cw && cw.classList.contains('minimized')) {
                cw.style.background = '';
                cw.style.borderRadius = '';
            }
            if(e) e.stopPropagation();
            chatWin.classList.toggle('minimized');
            chatWin.classList.remove('full-screen');
            if(chatWin.classList.contains('minimized')) {
                chatWin.style.left = ''; chatWin.style.top = ''; chatWin.style.right = '30px'; chatWin.style.bottom = '30px';
            } else {
                chatWin.classList.add('full-screen');
            }
            if(!chatWin.classList.contains('minimized') && msgEl.innerHTML === "") {
                openChatbotFlow('prospect');
            }
        }

        function addMsg(type, text) {
            const div = document.createElement('div');
            div.className = type === 'bot' ? 'msg-bot' : 'msg-user';
            div.innerHTML = text;
            msgEl.appendChild(div);
            div.scrollIntoView({ behavior: 'smooth', block: 'center' });
            if(type === 'bot') playBeep(880, 0.03);
        }

        function simulateTyping(callback, delay = 400) {
            const div = document.createElement('div');
            div.className = 'msg-bot typing-indicator';
            div.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
            msgEl.appendChild(div);
            div.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { div.remove(); callback(); }, delay);
        }

        function openChatbotFlow(type) {
            playBeep(440, 0.1);
            document.querySelector('nav').classList.add('compact-nav');
            chatWin.classList.remove('minimized');
            chatWin.classList.add('full-screen');
            msgEl.innerHTML = ""; ctrlEl.innerHTML = "";
            dataStore = { cp: "" };

            // Update Tabs UI
            document.querySelectorAll('.chat-tab').forEach(t => t.classList.remove('active'));
            const tabIdx = type === 'prospect' ? 0 : (type === 'prestataire' ? 1 : 2);
            if(document.querySelectorAll('.chat-tab')[tabIdx]) document.querySelectorAll('.chat-tab')[tabIdx].classList.add('active');

            if (type === 'prospect') {
                addMsg("bot", "<b>Coup d'main — Moteur d'Arbitrage.</b><br><span style='color:var(--text-muted);font-size:11px;'>Nous mettons votre besoin en concurrence directe auprès de notre base de prestataires certifiés pour extraire la meilleure offre du marché.</span>");
                simulateTyping(() => {
                    // FILTRE MALIK — ÉTAT A : Géographie non définie. BLOQUER TOUS LES SERVICES.
                    addMsg("bot", "<b>🌍 NIVEAU 1 — SOUVERAINETÉ.</b><br><span style='color:var(--text-muted);font-size:11px;'>Sélectionnez votre pays avant tout accès aux services.</span>");
                    dataStore.next_after_country = 'region';
                    addMsg("bot", "<span style='font-size:9px; color:var(--text-muted);'>🔒 En accédant au moteur, vous acceptez le traitement de vos données sous RGPD/LPD. Aucune vente à des tiers.</span>");
                    ctrlEl.innerHTML = `
                        <button class="ui-btn" onclick="gatekeeperEntry('BE','Belgique')" style="border-color:#FFB800;">🇧🇪 Belgique</button>
                        <button class="ui-btn" onclick="gatekeeperEntry('LU','Luxembourg')" style="border-color:#4EE0D9;">🇱🇺 Luxembourg</button>
                        <button class="ui-btn" onclick="gatekeeperEntry('CH','Suisse')" style="border-color:#D52B1E;">🇨🇭 Suisse</button>
                        <button class="ui-btn" onclick="gatekeeperEntry('FR','France')" style="border-color:#0055A4; font-size:11px;">🇫🇷 France</button>
                    `;
                });
            } else if (type === 'bigbang') {
                // MODULE BIG BANG AUTOMOBILE
                document.querySelectorAll('.chat-tab').forEach(t => t.classList.remove('active'));
                const bbTab = document.querySelectorAll('.chat-tab')[3];
                if(bbTab) bbTab.classList.add('active');
                addMsg("bot", "<b>🚗 MODULE BIG BANG — Import & Achat Automobile.</b>");
                addMsg("bot", "Sourcing inversé sur BE / LU / CH. Notre réseau couvre les 4 pays cibles.");
                simulateTyping(() => {
                    addMsg("bot", "<b>🌍 Zone d'intervention ?</b>");
                    ctrlEl.innerHTML = `
                        <button class="ui-btn" onclick="handleBigBangCountry('BE','Belgique')" style="border-color:#FFB800;">🇧🇪 Belgique</button>
                        <button class="ui-btn" onclick="handleBigBangCountry('LU','Luxembourg')" style="border-color:#002A54;">🇱🇺 Luxembourg</button>
                        <button class="ui-btn" onclick="handleBigBangCountry('CH','Suisse')" style="border-color:#D52B1E;">🇨🇭 Suisse</button>
                    `;
                });
            } else if (type === 'prestataire') {
                addMsg("bot", "<b>Espace Elite.</b> Certification prioritaire.");
                simulateTyping(() => {
                    ctrlEl.innerHTML = `
                        <div id="trust-bar-container" style="width:100%; height:4px; background:rgba(255,255,255,0.05); border-radius:2px; margin-bottom:10px; overflow:hidden;">
                            <div id="trust-bar-p" style="width:20%; height:100%; background:var(--accent); transition: width 0.4s ease;"></div>
                        </div>
                        <div class="compact-row">
                            <input type="text" id="p-nom" class="ui-select" placeholder="Entreprise" oninput="updateTrustScore('p')">
                            <input type="text" id="p-spe" class="ui-select" placeholder="Spécialité" oninput="updateTrustScore('p')">
                        </div>
                        <div class="compact-row">
                            <input type="tel" id="p-tel" class="ui-select" placeholder="Portable" oninput="updateTrustScore('p'); toggleExtra('p')">
                            <input type="email" id="p-email" class="ui-select" placeholder="Email Pro" oninput="updateTrustScore('p')">
                        </div>
                        <div style="font-size:9px; color:var(--text-muted); margin-bottom:8px; margin-left:5px;">✉️ Utilisé pour l'envoi de vos documents certifiés.</div>
                        
                        <div id="p-extra" style="display:none; animation: reveal 0.3s ease;">
                            <input type="text" id="p-tva" class="ui-select" placeholder="N° TVA / Entreprise" oninput="updateTrustScore('p')">
                            <div class="drop-zone" onclick="document.getElementById('p-photos').click()" style="padding:5px; font-size:10px; border:1px dashed var(--accent); text-align:center; height:32px; display:flex; align-items:center; justify-content:center;">🖼️ Photos de réalisations</div>
                            <input type="file" id="p-photos" style="display:none" multiple onchange="updateTrustScore('p')">
                            <div style="font-size:10px; color:var(--text-muted); margin: 5px 0; display:flex; gap:8px;">
                                <input type="checkbox" id="p-legal" onchange="updateTrustScore('p')">
                                <label for="p-legal">Je certifie mes informations.</label>
                            </div>
                        </div>
                        <button class="ui-btn" style="height:32px; font-size:10px;" onclick="submitArtisanFormInChat()">Postuler au réseau Elite</button>
                    `;
                });
            }
            else if (type === 'partenaire') {
                addMsg("bot", "<b>Espace Partenaire Elite.</b> Coup d'main.");
                simulateTyping(() => {
                    ctrlEl.innerHTML = `
                        <div class="compact-row">
                            <input type="text" id="pt-nom" class="ui-select" placeholder="Entreprise" oninput="updateTrustScore()">
                            <input type="text" id="pt-mat" class="ui-select" placeholder="Ressource" oninput="updateTrustScore()">
                        </div>
                        <div class="compact-row">
                            <input type="tel" id="pt-tel" class="ui-select" placeholder="Portable" oninput="updateTrustScore()">
                            <input type="email" id="pt-email" class="ui-select" placeholder="Email" oninput="updateTrustScore()">
                        </div>
                        <div style="font-size:9px; color:var(--text-muted); margin-bottom:8px; margin-left:5px;">🛡️ Stockage sécurisé de vos justificatifs logistiques.</div>
                        
                        <div id="pt-extra" style="display:none; animation: reveal 0.3s ease;">
                            <div class="compact-row">
                                <input type="text" id="pt-tva" class="ui-select" placeholder="N° TVA" oninput="updateTrustScore()">
                                <input type="text" id="pt-kbis" class="ui-select" placeholder="N° Entreprise" oninput="updateTrustScore()">
                            </div>
                            <div class="compact-row">
                                <input type="text" id="pt-ins" class="ui-select" placeholder="Assurance" oninput="updateTrustScore()">
                                <input type="text" id="pt-com" class="ui-select" placeholder="Com. (ex: 10% ou 10€ fixe)" oninput="updateTrustScore()">
                            </div>
                            <div class="compact-row" style="margin-top:4px;">
                                <select id="pt-stock" class="ui-select" onchange="updateTrustScore()">
                                    <option value="">-- Engagement Fournisseur --</option>
                                    <option value="verifie">Stock Vérifié & Délais Fermes</option>
                                    <option value="non_verifiable">Preuve non localisable</option>
                                </select>
                            </div>
                        </div>
                        <div style="font-size:8px; color:var(--text-muted); margin-bottom:5px;">💡 Règle Elite : Commission fixe de 10€ pour toute course < 100€.</div>
                        <button class="ui-btn" style="height:32px; font-size:10px;" onclick="submitPartenaireForm()">Ajouter au Catalogue</button>
                    `;
                });
            }
        }

        function toggleExtra(prefix) {
            const extra = document.getElementById(`${prefix}-extra`);
            if (extra) extra.style.display = 'block';
        }

        function updateTrustScore(prefix = 'pt') {
            const inputs = prefix === 'pt' 
                ? ['pt-nom', 'pt-mat', 'pt-tel', 'pt-email', 'pt-tva', 'pt-ins', 'pt-kbis', 'pt-com']
                : ['p-nom', 'p-spe', 'p-tel', 'p-email', 'p-tva', 'p-legal'];
            
            let score = 0;
            inputs.forEach(id => { 
                const el = document.getElementById(id);
                if (el) {
                    if (el.type === 'checkbox') { if(el.checked) score++; }
                    else if (el.type === 'file') { if(el.files && el.files.length > 0) score += 2; } // Les photos comptent double !
                    else { if(el.value) score++; }
                }
            });

            const maxScore = prefix === 'pt' ? inputs.length : inputs.length + 1; // Ajustement car photos comptent double
            const percent = Math.min((score / maxScore) * 100, 100);
            
            const bar = document.getElementById(prefix === 'pt' ? 'trust-bar' : 'trust-bar-p');
            const label = document.getElementById(prefix === 'pt' ? 'trust-label' : 'trust-label-p');
            
            if(bar) bar.style.width = percent + '%';
            if(label) {
                if(percent < 40) { label.innerText = "Confiance : Standard"; label.style.color = "#9BA1A6"; }
                else if(percent < 75) { label.innerText = "Confiance : Premium"; label.style.color = "var(--accent)"; }
                else { label.innerText = "Confiance : ELITE"; label.style.color = "var(--neon-green)"; bar.style.background = "var(--neon-green)"; }
            }
        }

        function openChatbotSpecific(famille, domaine) {
            const isResource = domaine.includes('Benne') || domaine.includes('Camionnette');
            
            if (isResource) {
                // FLUX PARTENAIRE : On propose du matériel
                openChatbotFlow('partenaire');
                setTimeout(() => {
                    const matInput = document.getElementById('pt-mat');
                    if (matInput) matInput.value = domaine;
                }, 1000);
            } else {
                // FLUX PROSPECT : On demande des travaux
                openChatbotFlow('prospect');
                setTimeout(() => {
                    handleSecteur(famille);
                    setTimeout(() => handleDomaine(domaine), 500);
                }, 500);
            }
        }

        function submitArtisanFormInChat() {
            const nom = document.getElementById('p-nom').value;
            const spe = document.getElementById('p-spe').value;
            const tel = document.getElementById('p-tel').value;
            const email = document.getElementById('p-email').value;
            const legal = document.getElementById('p-legal').checked;

            if(!nom || !spe || !tel || !email || !legal) {
                alert("Veuillez remplir tous les champs et accepter la décharge de responsabilité.");
                return;
            }
            addMsg("user", `Inscription : ${nom} (${spe}) - Tél: ${tel} - Email: ${email}`);
            ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", "<b>Félicitations pour votre demande !</b> Votre dossier est désormais en cours de vérification prioritaire par nos agents. Vous serez notifié dès validation de votre statut Elite.");
            });
        }

        function submitPartenaireForm() {
            const nom = document.getElementById('pt-nom').value;
            const mat = document.getElementById('pt-mat').value;
            const tel = document.getElementById('pt-tel').value;
            const email = document.getElementById('pt-email').value;
            if(!nom || !mat || !tel || !email) {
                alert("Tous les champs sont requis.");
                return;
            }
            addMsg("user", `Offre : ${mat} par ${nom} (${email})`);
            ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", "Matériel indexé dans le réseau Elite. Merci pour votre contribution à l'écosystème.");
            });
        }

        function handleSecteur(s) {
            if(!s) return;
            document.body.classList.add('focus-mode');
            dataStore.famille = s;
            updateArbScore('secteur', 20);
            addMsg("user", s); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", "Très bien, c'est noté. On poursuit avec la précision technique pour affiner notre recherche.");
                let html = `<select class="ui-select" onchange="handleDomaine(this.value)">
                    <option value="">-- Choisir --</option>`;
                Object.keys(matrixData[s]).forEach(d => html += `<option value="${d}">${d}</option>`);
                ctrlEl.innerHTML = html + `</select>`;
            });
        }

        function handleDomaine(d) {
            if(!d) return;
            dataStore.domaine = d;
            addMsg("user", d); ctrlEl.innerHTML = "";

            if (d === "Solaire Photovoltaïque") {
                simulateTyping(() => {
                    addMsg("bot", "Analyse contextuelle : S'agit-il d'une <b>nouvelle installation complète</b> ou avez-vous seulement besoin d'un <b>dossier de primes</b> pour une installation existante ?");
                    ctrlEl.innerHTML = `
                        <button class="ui-btn" onclick="handleSolaireChoice('travaux')" style="border-color:var(--accent)">🏗️ Nouvelle Installation</button>
                        <button class="ui-btn" onclick="handleSolaireChoice('primes')">📜 Dossier de Primes Seul</button>
                    `;
                });
                return;
            }

            simulateTyping(() => {
                addMsg("bot", "Quel est le type d'intervention requis ?");
                let btns = "";
                Object.keys(matrixData[dataStore.famille][d]).forEach(sc => {
                    btns += `<button class="ui-btn" onclick="handleSousCat('${sc}')">${sc}</button>`;
                });
                ctrlEl.innerHTML = btns;
            });
        }

        // ══════════════════════════════════════════════════════════════════
        // MOTEUR SOLAIRE ARBITRAGE — 6 étapes de qualification maximale
        // ══════════════════════════════════════════════════════════════════

        // Constantes de calcul (normes EU 2024)
        const SOLAIRE = {
            wc_par_panneau:   400,       // Wc moyen panneau standard 2024
            prix_kwh_reseau:  0.30,      // €/kWh moyen BE/FR/CH/LU
            heures_equiv: {              // Heures solaires équivalentes/an par pays
                BE: 900, FR: 1150, CH: 1050, LU: 950
            },
            coeff_orient: { 'Sud': 1.0, 'Est-Ouest': 0.82, 'Nord': 0.55 },
            coeff_incl:   { '30-45°': 1.0, '15-30°': 0.92, '< 15° (plat)': 0.85, '> 45°': 0.88 },
            cout_kwc:        1400,       // €/kWc fourni+posé (marché 2024)
            primes: {
                BE_WAL:  { label: 'Prime Wallonie RENOLUTION',  max: 3500 },
                BE_BXL:  { label: 'Prime Bruxelles (RENOLUTION)', max: 2800 },
                BE_FLA:  { label: 'Prime Flandre (MyRenovation)', max: 1500 },
                FR:      { label: "MaPrimeRénov' + CEE",        max: 4000 },
                CH:      { label: 'STC Suisse (Pronovo)',        max: 2200 },
                LU:      { label: 'Prime Klimabonus Luxembourg', max: 3000 }
            },
            certif: {
                BE: 'Qualibat / Quentra',
                FR: 'RGE QualiPV',
                CH: 'Qualité / Suisse Solaire',
                LU: 'qualit-es Luxembourg'
            }
        };


        // ── fetchSolarRegulations() — Async config loader ────────────────────
        // Interroge un fichier JSON externe pour mettre à jour les coefficients.
        // Si inaccessible → fallback silencieux sur const SOLAIRE (EU 2024).
        // URL du fichier de config : /solar-config.json (même dossier que index.html)
        // Structure attendue du JSON :
        // {
        //   "heures_equiv": { "BE": 900, "FR": 1150, "CH": 1050, "LU": 950 },
        //   "prix_kwh_reseau": 0.30,
        //   "cout_kwc": 1400,
        //   "primes": { "BE_WAL": { "label": "...", "max": 3500 }, ... },
        //   "certif": { "BE": "Qualibat / Quentra", ... }
        // }
        let _solarConfigLoaded = false;

        async function fetchSolarRegulations() {
            if (_solarConfigLoaded) return; // déjà chargé, pas de double fetch
            try {
                const ctrl = new AbortController();
                const timeout = setTimeout(() => ctrl.abort(), 4000); // timeout 4s
                const res = await fetch('./solar-config.json', {
                    signal: ctrl.signal,
                    cache:  'no-cache'
                });
                clearTimeout(timeout);
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                const cfg = await res.json();

                // Merge sélectif — on n'écrase que les clés présentes dans le JSON
                if (cfg.heures_equiv)     Object.assign(SOLAIRE.heures_equiv,  cfg.heures_equiv);
                if (cfg.prix_kwh_reseau)  SOLAIRE.prix_kwh_reseau = cfg.prix_kwh_reseau;
                if (cfg.cout_kwc)         SOLAIRE.cout_kwc         = cfg.cout_kwc;
                if (cfg.primes)           Object.assign(SOLAIRE.primes,  cfg.primes);
                if (cfg.certif)           Object.assign(SOLAIRE.certif,  cfg.certif);
                if (cfg.coeff_orient)     Object.assign(SOLAIRE.coeff_orient, cfg.coeff_orient);
                if (cfg.coeff_incl)       Object.assign(SOLAIRE.coeff_incl,   cfg.coeff_incl);

                _solarConfigLoaded = true;
                console.log('[CDM Solar] Config externe chargée ✅');
            } catch (err) {
                // Fallback silencieux — SOLAIRE conserve ses valeurs EU 2024
                if (err.name === 'AbortError') {
                    console.warn('[CDM Solar] Timeout config externe — fallback EU 2024');
                } else {
                    console.warn('[CDM Solar] Config externe inaccessible — fallback EU 2024:', err.message);
                }
            }
        }
        // ── FIN fetchSolarRegulations ─────────────────────────────────────────

        function handleSolaireChoice(choice) {
            dataStore.type_solaire = choice;
            addMsg("user", choice === 'travaux' ? "Nouvelle Installation" : "Dossier de Primes");
            ctrlEl.innerHTML = "";

            // Charge la config externe si disponible (fallback silencieux sur EU 2024)
            fetchSolarRegulations();

            if (choice === 'primes') {
                simulateTyping(() => {
                    addMsg("bot", "Pour maximiser vos primes, notre moteur a besoin de valider votre éligibilité technique. Les données suivantes déterminent le montant exact auquel vous avez droit — une erreur ici = des milliers d'euros de primes perdues.");
                    setTimeout(() => solaireStep1_Panneaux(), 500);
                });
                return;
            }
            // Nouvelle installation → flux complet
            simulateTyping(() => {
                addMsg("bot", "<b>☀️ ARBITRAGE SOLAIRE ACTIVÉ</b><br><span style='color:var(--text-muted);font-size:11px;'>Chaque donnée que vous fournissez est transmise directement aux installateurs certifiés de notre réseau. Sans ces données, ils ne peuvent pas s'engager sur un prix ferme. Avec elles, vous recevez des offres comparables dès 48h.</span>");
                setTimeout(() => solaireStep1_Panneaux(), 600);
            });
        }

        // ÉTAPE 1 — Nombre et puissance visés
        function solaireStep1_Panneaux() {
            simulateTyping(() => {
                addMsg("bot", "<b>CRITÈRE 1/6 — Puissance visée</b><br><span style='color:var(--text-muted);font-size:11px;'>Ce critère détermine la classe d'installateurs sollicités et les primes applicables. Un système < 5kWc et > 10kWc n'ont pas les mêmes certifications requises.</span>");
                ctrlEl.innerHTML = `
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        <button class="ui-btn" onclick="solaireSetPuissance(6,15,'< 5 kWc')">⚡ < 5 kWc<br><span style='font-size:9px;color:var(--text-muted);'>≈ 10-12 panneaux</span></button>
                        <button class="ui-btn" onclick="solaireSetPuissance(10,25,'5 à 10 kWc')" style="border-color:var(--accent)">⚡ 5 à 10 kWc<br><span style='font-size:9px;color:var(--text-muted);'>≈ 13-25 panneaux ★</span></button>
                        <button class="ui-btn" onclick="solaireSetPuissance(16,40,'10 à 16 kWc')">⚡ 10 à 16 kWc<br><span style='font-size:9px;color:var(--text-muted);'>≈ 26-40 panneaux</span></button>
                        <button class="ui-btn" onclick="solaireSetPuissance(20,50,'Installation professionnelle / agricole')">🏭 > 16 kWc<br><span style='font-size:9px;color:var(--text-muted);'>Pro / Agricole</span></button>
                    </div>
                    <div style="margin-top:10px;display:flex;gap:8px;align-items:center;">
                        <input type="number" id="nb-panneaux" class="ui-select" placeholder="Nombre exact (ex: 20)" style="flex:1;">
                        <button class="ui-btn" onclick="solaireSetPanneauxExact()" style="width:auto;padding:10px 14px;">OK</button>
                    </div>
                `;
            });
        }

        function solaireSetPuissance(kwc_min, nb_equiv, label) {
            dataStore.solaire_kwc = kwc_min;
            dataStore.solaire_nb = nb_equiv;
            dataStore.solaire_gamme = label;
            addMsg("user", label + " — ≈" + nb_equiv + " panneaux");
            ctrlEl.innerHTML = "";
            solaireStep2_Conso();
        }

        function solaireSetPanneauxExact() {
            const nb = parseInt(document.getElementById('nb-panneaux').value);
            if (!nb || nb < 1 || nb > 500) { alert("Nombre de panneaux invalide (1-500)."); return; }
            const kwc = Math.round(nb * SOLAIRE.wc_par_panneau / 1000 * 10) / 10;
            const gamme = kwc < 5 ? '< 5 kWc' : kwc <= 10 ? '5 à 10 kWc' : kwc <= 16 ? '10 à 16 kWc' : '> 16 kWc';
            dataStore.solaire_nb  = nb;
            dataStore.solaire_kwc = kwc;
            dataStore.solaire_gamme = gamme;
            addMsg("user", `${nb} panneaux → ${kwc} kWc`);
            ctrlEl.innerHTML = "";
            solaireStep2_Conso();
        }

        // ÉTAPE 2 — Consommation réelle
        function solaireStep2_Conso() {
            simulateTyping(() => {
                addMsg("bot", `<b>CRITÈRE 2/6 — Consommation annuelle</b><br><span style='color:var(--text-muted);font-size:11px;'>Donnée issue de votre facture électrique. Permet de calculer le taux d'autoconsommation réel et le retour sur investissement exact. Sans cette donnée, tout chiffrage est une estimation de catalogue — pas un arbitrage.</span>`);
                ctrlEl.innerHTML = `
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
                        <button class="ui-btn" onclick="solaireSetConso(2500,'Maison < 100m²')">🏠 < 2 500 kWh<br><span style='font-size:9px;color:var(--text-muted);'>Maison < 100m²</span></button>
                        <button class="ui-btn" onclick="solaireSetConso(4000,'Maison 100-200m²')" style="border-color:var(--accent)">🏠 2 500-5 000 kWh<br><span style='font-size:9px;color:var(--text-muted);'>Maison 100-200m² ★</span></button>
                        <button class="ui-btn" onclick="solaireSetConso(7000,'Grande maison / PAC')">🏡 5 000-10 000 kWh<br><span style='font-size:9px;color:var(--text-muted);'>Grande maison / PAC</span></button>
                        <button class="ui-btn" onclick="solaireSetConso(15000,'Professionnel / Industrie')">🏭 > 10 000 kWh<br><span style='font-size:9px;color:var(--text-muted);'>Pro / Industrie</span></button>
                    </div>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <input type="number" id="conso-exact" class="ui-select" placeholder="kWh/an exact (ex: 3800)" style="flex:1;">
                        <button class="ui-btn" onclick="solaireSetConsoExact()" style="width:auto;padding:10px 14px;">OK</button>
                    </div>
                `;
            });
        }

        function solaireSetConso(kwh, label) {
            dataStore.consommation_kwh = kwh;
            addMsg("user", label + " — " + kwh + " kWh/an");
            ctrlEl.innerHTML = "";
            solaireStep3_Toiture();
        }

        function solaireSetConsoExact() {
            const kwh = parseInt(document.getElementById('conso-exact').value);
            if (!kwh || kwh < 100) { alert("Saisissez votre consommation annuelle en kWh."); return; }
            dataStore.consommation_kwh = kwh;
            addMsg("user", kwh + " kWh/an");
            ctrlEl.innerHTML = "";
            solaireStep3_Toiture();
        }

        // ÉTAPE 3 — Configuration toiture
        function solaireStep3_Toiture() {
            simulateTyping(() => {
                addMsg("bot", "<b>CRITÈRE 3/6 — Configuration de toiture</b><br><span style='color:var(--text-muted);font-size:11px;'>L'orientation et l'inclinaison déterminent le rendement réel de l'installation. Un toit nord avec une mauvaise inclinaison peut réduire le rendement de 45%. Ces données conditionnent les offres des installateurs.</span>");
                ctrlEl.innerHTML = `
                    <div style="margin-bottom:8px;font-size:11px;color:var(--text-muted);">Orientation du pan principal</div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:12px;">
                        <button class="ui-btn" onclick="document.querySelectorAll('.orient-btn').forEach(b=>b.classList.remove('active-btn')); this.classList.add('active-btn'); dataStore.orientation='Sud';" style="border-color:var(--neon-green)" class="orient-btn">☀️ Sud</button>
                        <button class="ui-btn" onclick="document.querySelectorAll('.orient-btn').forEach(b=>b.classList.remove('active-btn')); this.classList.add('active-btn'); dataStore.orientation='Est-Ouest';" class="orient-btn">↔️ Est/Ouest</button>
                        <button class="ui-btn" onclick="document.querySelectorAll('.orient-btn').forEach(b=>b.classList.remove('active-btn')); this.classList.add('active-btn'); dataStore.orientation='Nord';" class="orient-btn">🌑 Nord</button>
                    </div>
                    <div style="margin-bottom:8px;font-size:11px;color:var(--text-muted);">Inclinaison de la toiture</div>
                    <select id="s-inclin" class="ui-select" style="margin-bottom:10px;">
                        <option value="30-45°">30-45° (Optimal)</option>
                        <option value="15-30°">15-30°</option>
                        <option value="< 15° (plat)">< 15° (toit plat / roofing)</option>
                        <option value="> 45°">> 45° (ardoise raide)</option>
                    </select>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
                        <div>
                            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">Surface disponible (m²)</div>
                            <input type="number" id="s-surf" class="ui-select" placeholder="Ex: 40">
                        </div>
                        <div>
                            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">Type de couverture</div>
                            <select id="s-type" class="ui-select">
                                <option value="Tuiles">Tuiles</option>
                                <option value="Ardoises">Ardoises</option>
                                <option value="Toit plat / Roofing">Toit plat / Roofing</option>
                                <option value="Bac acier / Shed">Bac acier / Shed</option>
                            </select>
                        </div>
                    </div>
                    <button class="ui-btn" onclick="solaireSubmitToiture()" style="border-color:var(--accent)">VALIDER LA CONFIGURATION</button>
                `;
            });
        }

        function solaireSubmitToiture() {
            if (!dataStore.orientation) { alert("Sélectionnez l'orientation."); return; }
            const surf = document.getElementById('s-surf').value;
            if (!surf || surf < 5) { alert("Surface invalide (minimum 5m²)."); return; }
            dataStore.inclinaison   = document.getElementById('s-inclin').value;
            dataStore.surface       = surf;
            dataStore.toiture_type  = document.getElementById('s-type').value;
            addMsg("user", `Toiture ${dataStore.toiture_type} — ${surf}m² — ${dataStore.orientation} — ${dataStore.inclinaison}`);
            ctrlEl.innerHTML = "";
            solaireStep4_Stockage();
        }

        // ÉTAPE 4 — Stockage et réseau
        function solaireStep4_Stockage() {
            simulateTyping(() => {
                addMsg("bot", "<b>CRITÈRE 4/6 — Stockage & Injection réseau</b><br><span style='color:var(--text-muted);font-size:11px;'>Ce choix détermine la rentabilité à 10 ans et les certifications requises pour les installateurs. Batterie = ROI plus long mais indépendance totale. Injection = ROI plus court avec revenus de vente.</span>");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="solaireSetStockage('Autoconsommation totale (batterie)')" style="border-color:var(--accent)">🔋 Avec batterie de stockage<br><span style='font-size:9px;color:var(--text-muted);'>Indépendance maximale — ROI 8-12 ans</span></button>
                    <button class="ui-btn" onclick="solaireSetStockage('Autoconsommation + injection réseau')">⚡ Sans batterie — Injection réseau<br><span style='font-size:9px;color:var(--text-muted);'>ROI 5-8 ans — Revenus injection</span></button>
                    <button class="ui-btn" onclick="solaireSetStockage('Injection totale (site non habité)')">🏭 Injection totale<br><span style='font-size:9px;color:var(--text-muted);'>Site industriel / agricole non habité</span></button>
                `;
            });
        }

        function solaireSetStockage(type) {
            dataStore.solaire_stockage = type;
            addMsg("user", type);
            ctrlEl.innerHTML = "";
            solaireStep5_Photos();
        }

        // ÉTAPE 5 — Preuves visuelles obligatoires
        function solaireStep5_Photos() {
            simulateTyping(() => {
                addMsg("bot", "<b>CRITÈRE 5/6 — Preuves visuelles obligatoires</b><br><span style='color:var(--text-muted);font-size:11px;'>Sans ces photos, aucun installateur certifié ne peut s'engager sur un prix ferme. Ce n'est pas une formalité — c'est ce qui sépare une offre d'arbitrage réelle d'un devis approximatif. Obligatoire pour accéder aux primes.</span>");
                ctrlEl.innerHTML = `
                    <div class="drop-zone" onclick="document.getElementById('s-photo-elec').click()" id="dz-elec">
                        📸 Photo du tableau électrique (ouvert)
                        <div style="font-size:9px;color:var(--text-muted);margin-top:4px;">Monophasé / Triphasé — Capacité du disjoncteur principal</div>
                    </div>
                    <input type="file" id="s-photo-elec" accept="image/*" style="display:none"
                        onchange="document.getElementById('dz-elec').innerHTML='✅ Tableau électrique OK<br><span style=\'font-size:9px;color:var(--neon-green);\'>Fichier : '+this.files[0].name+'</span>'; dataStore.photo_elec=true;">

                    <div class="drop-zone" onclick="document.getElementById('s-photo-toit').click()" id="dz-toit" style="margin-top:10px;">
                        📸 Photo de la toiture (vue dégagée)
                        <div style="font-size:9px;color:var(--text-muted);margin-top:4px;">Pan principal visible — Cheminées et obstacles inclus</div>
                    </div>
                    <input type="file" id="s-photo-toit" accept="image/*" style="display:none"
                        onchange="document.getElementById('dz-toit').innerHTML='✅ Photo toiture OK<br><span style=\'font-size:9px;color:var(--neon-green);\'>Fichier : '+this.files[0].name+'</span>'; dataStore.photo_toit=true;">

                    <div class="drop-zone" onclick="document.getElementById('s-photo-facture').click()" id="dz-facture" style="margin-top:10px;">
                        📄 Dernière facture électrique (facultatif mais recommandé)
                        <div style="font-size:9px;color:var(--text-muted);margin-top:4px;">Accélère le calcul de prime de 40%</div>
                    </div>
                    <input type="file" id="s-photo-facture" accept="image/*,application/pdf" style="display:none"
                        onchange="document.getElementById('dz-facture').innerHTML='✅ Facture OK<br><span style=\'font-size:9px;color:var(--neon-green);\'>Fichier : '+this.files[0].name+'</span>'; dataStore.photo_facture=true;">

                    <button class="ui-btn" onclick="solaireValidatePhotos()" style="border-color:var(--accent);margin-top:15px;">VALIDER LES DOCUMENTS</button>
                `;
            });
        }

        function solaireValidatePhotos() {
            if (!dataStore.photo_elec || !dataStore.photo_toit) {
                recordFault('photos_solaire_manquantes');
                addMsg("bot", "❌ <b>Tableau électrique et toiture obligatoires.</b><br><span style='font-size:11px;color:var(--text-muted);'>Sans ces deux visuels, les installateurs certifiés ne peuvent pas valider techniquement le dossier. Ce sont des prérequis non négociables pour l'arbitrage.</span>");
                return;
            }
            addMsg("user", "Documents transmis ✅");
            ctrlEl.innerHTML = "";
            solaireStep6_Calcul();
        }

        // ÉTAPE 6 — Calcul de rentabilité + routing installateurs certifiés
        function solaireStep6_Calcul() {
            simulateTyping(() => {
                addMsg("bot", "<b>⚙️ Calcul de rentabilité en cours...</b><br><span style='color:var(--text-muted);font-size:11px;'>Normes EU 2024 — Ensoleillement local — Tarif réseau — Primes applicables</span>");

                setTimeout(() => {
                    // Calcul production annuelle
                    const code    = dataStore.country_code || 'BE';
                    const hEq     = SOLAIRE.heures_equiv[code] || 950;
                    const cOrient = SOLAIRE.coeff_orient[dataStore.orientation] || 0.85;
                    const cIncl   = SOLAIRE.coeff_incl[dataStore.inclinaison]   || 0.92;
                    const kwc     = dataStore.solaire_kwc || 6;
                    const kwh_an  = Math.round(kwc * hEq * cOrient * cIncl);

                    // Économie annuelle
                    const conso   = dataStore.consommation_kwh || 4000;
                    const autocon = Math.min(kwh_an, conso * 0.6); // max 60% autoconsommé
                    const inject  = Math.max(0, kwh_an - autocon);
                    const eco_an  = Math.round(autocon * SOLAIRE.prix_kwh_reseau + inject * 0.07); // injection à 0.07€/kWh

                    // Coût installation
                    const cout_inst = Math.round(kwc * SOLAIRE.cout_kwc);

                    // Prime applicable
                    const region = dataStore.region || '';
                    let primeKey = code;
                    if (code === 'BE') {
                        if (region === 'Bruxelles-Capitale') primeKey = 'BE_BXL';
                        else if (region === 'Flandre') primeKey = 'BE_FLA';
                        else primeKey = 'BE_WAL';
                    }
                    const primeData   = SOLAIRE.primes[primeKey] || SOLAIRE.primes['BE_WAL'];
                    const prime_est   = Math.min(primeData.max, Math.round(kwc * 350));
                    const cout_net    = cout_inst - prime_est;
                    const roi_ans     = eco_an > 0 ? Math.round(cout_net / eco_an * 10) / 10 : 99;
                    const certif      = SOLAIRE.certif[code] || 'Qualibat';
                    const gain_10ans  = eco_an * 10 - cout_net;

                    // Stocker pour EmailJS
                    dataStore.solaire_production   = kwh_an;
                    dataStore.solaire_eco_an        = eco_an;
                    dataStore.solaire_cout_inst     = cout_inst;
                    dataStore.solaire_prime         = prime_est;
                    dataStore.solaire_roi           = roi_ans;
                    dataStore.solaire_gain_10ans    = gain_10ans;
                    dataStore.solaire_certif        = certif;
                    dataStore.estimate_D            = cout_inst;
                    dataStore.commission_B          = Math.round(cout_inst * 0.08); // 8% commission arbitrage

                    // Affichage résultat
                    const gainColor = gain_10ans > 0 ? 'var(--neon-green)' : 'var(--accent)';
                    addMsg("bot", `
                        <div style="background:linear-gradient(135deg,rgba(0,255,102,0.06),rgba(11,14,17,0));border:1px solid rgba(0,255,102,0.2);border-radius:12px;padding:16px;margin:4px 0;">
                            <div style="font-size:9px;letter-spacing:3px;color:var(--text-muted);margin-bottom:10px;">RÉSULTAT D'ARBITRAGE SOLAIRE — ${kwc} kWc / ${dataStore.solaire_nb} panneaux</div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
                                <div style="text-align:center;padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;">
                                    <div style="font-size:20px;font-weight:900;color:var(--neon-green);">${kwh_an.toLocaleString('fr-FR')}</div>
                                    <div style="font-size:9px;color:var(--text-muted);">kWh produits/an</div>
                                </div>
                                <div style="text-align:center;padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;">
                                    <div style="font-size:20px;font-weight:900;color:var(--accent);">${eco_an.toLocaleString('fr-FR')}€</div>
                                    <div style="font-size:9px;color:var(--text-muted);">économies/an estimées</div>
                                </div>
                                <div style="text-align:center;padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;">
                                    <div style="font-size:20px;font-weight:900;color:var(--gold);">${prime_est.toLocaleString('fr-FR')}€</div>
                                    <div style="font-size:9px;color:var(--text-muted);">${primeData.label}</div>
                                </div>
                                <div style="text-align:center;padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;">
                                    <div style="font-size:20px;font-weight:900;color:var(--text-main);">${roi_ans} ans</div>
                                    <div style="font-size:9px;color:var(--text-muted);">retour sur investissement</div>
                                </div>
                            </div>
                            <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:10px;">
                                <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
                                    <span style="font-size:11px;color:var(--text-muted);">Coût installation estimé</span>
                                    <span style="font-size:11px;font-weight:700;">${cout_inst.toLocaleString('fr-FR')}€</span>
                                </div>
                                <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
                                    <span style="font-size:11px;color:var(--text-muted);">Prime déduite (${primeData.label})</span>
                                    <span style="font-size:11px;font-weight:700;color:var(--gold);">-${prime_est.toLocaleString('fr-FR')}€</span>
                                </div>
                                <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                                    <span style="font-size:12px;font-weight:700;">Coût net réel</span>
                                    <span style="font-size:12px;font-weight:900;color:var(--accent);">${cout_net.toLocaleString('fr-FR')}€</span>
                                </div>
                                <div style="text-align:center;padding:8px;background:rgba(0,255,102,0.06);border-radius:6px;">
                                    <span style="font-size:11px;color:${gainColor};font-weight:700;">
                                        ${gain_10ans > 0 ? '✅ Gain net sur 10 ans : +' + gain_10ans.toLocaleString('fr-FR') + '€' : '⚠️ Point mort à ' + roi_ans + ' ans'}
                                    </span>
                                </div>
                            </div>
                            <div style="margin-top:10px;font-size:9px;color:var(--text-muted);border-top:1px solid rgba(255,255,255,0.04);padding-top:8px;">
                                Installateurs requis : certifiés <b style="color:#fff;">${certif}</b> · Calcul selon ensoleillement ${code} (${hEq}h/an équivalent) · Normes EU 2024
                            </div>
                        </div>
                    `);

                    setTimeout(() => {
                        addMsg("bot", `Notre moteur va maintenant solliciter <b>3 installateurs certifiés ${certif}</b> dans votre zone pour des offres fermes et comparables.<br><span style='font-size:11px;color:var(--text-muted);'>Frais de coordination d'arbitrage : 15€ — déductibles si vous contractualisez via la plateforme.</span>`);
                        setTimeout(() => askContact(), 1200);
                    }, 1000);
                }, 1800);
            });
        }


        // ── AGENT 2 : TAMIS EXPERT — Score de qualification ─────────────────
        const ARB_SCORE = { geo: 0, secteur: 0, detail: 0, urgence: 0, contact: 0, typeform: 0 };

        function updateArbScore(field, pts) {
            ARB_SCORE[field] = pts;
            const total = Math.min(100, Object.values(ARB_SCORE).reduce((a,b) => a+b, 0));
            const el = document.getElementById('arb-score');
            const pct = document.getElementById('arb-pct');
            if (el && pct) {
                el.style.display = 'block';
                pct.textContent = total;
                // Color graduation
                el.style.color = total >= 80 ? 'var(--neon-green)' : total >= 50 ? 'var(--accent)' : 'var(--text-muted)';
            }
        }

        // Hook score updates to key flow events
        const _origGeoLock = window.geoLockCommune;
        // ── FIN AGENT 2 ──────────────────────────────────────────────────────



        // ── CROSS-SELLING — Matrice prédictive par secteur ───────────────────
        function _getCrossSell(famille, domaine) {
            const map = {
                "Location & Logistique": { title: "Besoin d'un monte-meuble ?", desc: "Livraison au 3ème étage ou plus ? Nos opérateurs avec monte-meuble sont disponibles dans l'heure.", cta: "RÉSERVER UN MONTE-MEUBLE", famille: "Location & Logistique", domaine: "Transport & Déménagement" },
                "Énergie & Rénovation":  { title: "Optimisez vos primes énergétiques", desc: "Votre installation ouvre droit à des subventions supplémentaires. Notre conseiller les identifie gratuitement.", cta: "VÉRIFIER MES PRIMES", famille: "Énergie & Rénovation", domaine: "Solaire Photovoltaïque" },
                "Bâtiment & Travaux":    { title: "Protection de chantier incluse ?", desc: "Bâches, filets et protections périmétriques — disponibles à la location dans votre zone.", cta: "PROTÉGER MON CHANTIER", famille: "Location & Logistique", domaine: "Location de Benne & Déchets" },
                "Nettoyage & Entretien": { title: "Évacuation des déchets de nettoyage", desc: "Déchets de chantier ou encombrants ? Une benne ou un BigBag livré sous 2h.", cta: "COMMANDER UNE BENNE", famille: "Location & Logistique", domaine: "Location de Benne & Déchets" },
            };
            return map[famille] || null;
        }
        // ── FIN CROSS-SELLING ────────────────────────────────────────────────


        // ── BADGE CONDITIONNEL — Catégorie d'intervention ────────────────────
        function getInterventionBadge(country_code, famille, domaine, sous_cat) {
            const isUrgence = (famille || '').toLowerCase().includes('urgence')
                || (domaine || '').toLowerCase().includes('urgence')
                || (domaine || '').toLowerCase().includes('dépannage')
                || (sous_cat || '').toLowerCase().includes('fuite')
                || (sous_cat || '').toLowerCase().includes('serrure')
                || (sous_cat || '').toLowerCase().includes('porte claquée');

            const isEnergie = (famille || '').includes('Énergie')
                || (domaine || '').includes('Solaire')
                || (domaine || '').includes('PAC')
                || (domaine || '').includes('Isolation')
                || (domaine || '').includes('Toiture');

            let badge = '';
            if (country_code === 'CH') {
                badge = "<div style='margin-top:5px;font-size:11px;color:#fff;background:#D52B1E;padding:4px;border-radius:3px;display:inline-block;'>🇨🇭 Conformité Normes SIA - Qualité Garantie</div>";
            } else if (country_code === 'LU') {
                badge = "<div style='margin-top:5px;font-size:11px;color:#fff;background:#002A54;padding:4px;border-radius:3px;display:inline-block;'>🇱🇺 Label Artisanat de Confiance - Critères LENOZ</div>";
            } else if (isUrgence) {
                // Urgence : CSTC et primes masqués
                badge = "<div style='margin-top:5px;font-size:11px;color:#fff;background:#1a1a1a;border:1px solid var(--neon-green);padding:4px;border-radius:3px;display:inline-block;'>⚡ Artisan Certifié - Intervention Sécurisée - Tarifs Transparents</div>";
            } else if (isEnergie) {
                // Gros œuvre / transition : CSTC + primes
                badge = "<div style='margin-top:5px;font-size:11px;color:#fff;background:#222;border:1px solid var(--accent);padding:4px;border-radius:3px;display:inline-block;'>🏗️ Agréé CSTC / Buildwise - Éligible Primes Régionales & d'État</div>";
            } else {
                // Standard
                badge = "<div style='margin-top:5px;font-size:11px;color:#fff;background:#222;border:1px solid var(--accent);padding:4px;border-radius:3px;display:inline-block;'>✅ Artisan Vérifié - Devis Transparent - Intervention Planifiée</div>";
            }
            return badge;
        }
        // ── FIN BADGE CONDITIONNEL ────────────────────────────────────────────
        // ── AGENT 3 : SUPERVISEUR — Règle Double Faute ───────────────────────
        let _faultCount = 0;

        function recordFault(reason) {
            _faultCount++;
            console.warn('[SUPERVISEUR] Faute #' + _faultCount + ' — ' + reason);
            if (_faultCount >= 2) {
                escalateToVisitePayante(reason);
                return true; // fault triggered escalation
            }
            return false;
        }

        function escalateToVisitePayante(reason) {
            _faultCount = 0; // reset
            ctrlEl.innerHTML = '';
            simulateTyping(() => {
                addMsg("bot", `⚠️ <b>Dossier suspendu.</b><br><span style='color:var(--text-muted);font-size:11px;'>Deux incohérences détectées dans votre dossier. Notre moteur ne peut pas produire une estimation ferme sans données fiables.<br>Une visite technique sur site est nécessaire pour débloquer l'arbitrage.</span>`);
                setTimeout(() => {
                    ctrlEl.innerHTML = `
                        <div style="background:rgba(212,175,55,0.08); border:1px solid var(--gold); border-radius:10px; padding:14px; margin-bottom:10px; text-align:center;">
                            <div style="font-size:10px; color:var(--text-muted); margin-bottom:4px;">VISITE TECHNIQUE D'ARBITRAGE</div>
                            <div style="font-size:26px; font-weight:900; color:var(--gold);">49 €</div>
                            <div style="font-size:10px; color:var(--text-muted);">Déductible sur la mission • Déplacement inclus</div>
                        </div>
                        <button class="pay-btn" onclick="triggerPaymentStep1(49)" style="background:var(--gold); color:#000;">🔧 RÉSERVER LA VISITE TECHNIQUE — 49€</button>
                        <button class="ui-btn" onclick="location.reload()" style="font-size:10px; opacity:0.5; margin-top:6px;">Recommencer le diagnostic</button>
                    `;
                }, 600);
            });
        }
        // ── FIN AGENT 3 ──────────────────────────────────────────────────────

        // ARBITRAGE CONTEXT — Messages de friction légitimée par domaine
        const ARBITRAGE_CONTEXT = {
            'Solaire Photovoltaïque': {
                icon: '☀️',
                msg: "Les données suivantes sont indispensables pour lancer un appel d'offres réel auprès de nos installateurs certifiés (Qualipv / QualiSol). Sans elles, les offres reçues seront des prix catalogue, non des prix d'arbitrage. Vous économisez en moyenne <b>18-34%</b> grâce à la mise en concurrence."
            },
            'Pompes à Chaleur (PAC)': {
                icon: '🌡️',
                msg: "Une PAC se dimensionne sur la surface chauffée, le type de construction et la DJU locale. Ces critères déterminent la puissance optimale. Nous les transmettons directement aux installateurs pour que leurs offres soient fermes et comparables — pas des fourchettes."
            },
            'Toiture & Isolation': {
                icon: '🏠',
                msg: "Le chiffrage en toiture dépend de la pente, du type de tuile et de la surface. Nos prestataires s'engagent sur prix ferme uniquement sur base de ces données. C'est ce qui différencie une offre d'arbitrage d'un devis standard."
            },
            'Électricité & Domotique': {
                icon: '⚡',
                msg: "La conformité électrique et le chiffrage varient fortement selon l'ancienneté du tableau et la norme applicable (RGIE/NIN/NIBT). Ces données permettent à nos électriciens de se positionner avec précision dès le premier contact."
            },
            'Maçonnerie & Gros Œuvre': {
                icon: '🧱',
                msg: "Le gros œuvre nécessite une caractérisation précise de la structure. Sans cela, les prestataires ne peuvent pas s'engager sur un prix. Nous collectons ces données pour que la mise en concurrence produise des offres réellement comparables."
            },
            'Plomberie & Chauffage': {
                icon: '🔧',
                msg: "La nature de l'installation (cuivre, PER, inox) et la pression réseau conditionnent l'intervention. Ces informations permettent à nos plombiers de chiffrer au premier passage — sans visite exploratoire facturée."
            }
        };

        function injectArbitrageContext(domaine) {
            const ctx = ARBITRAGE_CONTEXT[domaine];
            if (!ctx) return;
            simulateTyping(() => {
                addMsg("bot", `${ctx.icon} <b>Pourquoi ces questions ?</b><br><span style='font-size:11px; color:var(--text-muted); line-height:1.6;'>${ctx.msg}</span>`);
            }, 300);
        }

        function handleSousCat(sc) {
            dataStore.sous_cat = sc;
            addMsg("user", sc); ctrlEl.innerHTML = "";
            
            simulateTyping(() => {
                if (dataStore.famille === 'Location & Logistique' || dataStore.famille === 'Automobile & Mobilité') {
                    // PYRAMIDE ANTI-GRAVITY : Pour Retrait Magasin, le PAYS passe EN PREMIER
                    if (sc.includes('Retrait Magasin')) {
                        // Stocker l'intention pour que selectCountry sache quoi faire après
                        dataStore.next_after_country = 'precision_retrait';
                        askCountry();
                        return;
                    }
                    // Pour les autres sous-cats logistiques : Accessibilité d'abord
                    const needsAccessibility = dataStore.domaine.includes('Transport') || sc.includes('Évacuation') || sc.includes('Déménagement');
                    if (needsAccessibility) {
                        addMsg("bot", "Précisez l'accessibilité pour l'intervention :");
                        ctrlEl.innerHTML = `
                            <button class="ui-btn" onclick="handleAccessibility('Rez-de-chaussée')">Rez-de-chaussée</button>
                            <button class="ui-btn" onclick="handleAccessibility('Étage avec ascenseur')">Étage avec ascenseur</button>
                            <button class="ui-btn" onclick="handleAccessibility('Étage sans ascenseur')">Étage sans ascenseur</button>
                        `;
                    } else {
                        proceedToPrecision(sc);
                    }
                } else {
                    addMsg("bot", "Êtes-vous propriétaire ou locataire de ce bien ?");
                    ctrlEl.innerHTML = `
                        <button class="ui-btn" onclick="handleGuestReady('Propriétaire')" style="border-color:var(--accent)">Propriétaire / Acquisition</button>
                        <button class="ui-btn" onclick="handleGuestReady('Locataire')">Locataire</button>
                    `;
                }
            });
        }

        function handleAccessibility(acc) {
            dataStore.accessibilite = acc;
            addMsg("user", acc); ctrlEl.innerHTML = "";
            proceedToPrecision(dataStore.sous_cat);
        }

        function handleGuestReady(status) {
            dataStore.statut_occupation = status;
            addMsg("user", status); ctrlEl.innerHTML = "";
            
            simulateTyping(() => {
                if (status === 'Locataire') {
                    // Conditional Logic : locataire → skip proof/pricing → Typeform capture directe
                    addMsg("bot", "ℹ️ <b>Statut locataire détecté.</b><br><span style='color:var(--text-muted);font-size:11px;'>Certaines interventions structurelles nécessitent l'accord du propriétaire. Nous orientons votre dossier vers notre formulaire de qualification — un conseiller prendra contact pour valider les autorisations requises.</span>");
                    setTimeout(() => {
                        addMsg("bot", "<b>Complétez votre dossier ci-dessous</b> pour que notre équipe puisse vous recontacter avec une solution adaptée à votre statut.");
                        ctrlEl.innerHTML = `
                            <button class="pay-btn" onclick="openTypeform(dataStore)" style="background:var(--accent); color:#000; margin-bottom:8px;">
                                📋 Compléter mon dossier — Qualification gratuite
                            </button>
                            <button class="ui-btn" onclick="proceedToPrecision(dataStore.sous_cat)" style="font-size:10px; opacity:0.55;">
                                Continuer quand même
                            </button>
                        `;
                    }, 800);
                    return;
                }
                if (status === 'Propriétaire') {
                    addMsg("bot", "✅ <b>Statut propriétaire confirmé.</b> Accès complet au moteur d'arbitrage.");
                    dataStore.is_guestready_lead = true;
                }
                proceedToPrecision(dataStore.sous_cat);
            });
        }
        
        function proceedToPrecision(sc) {
            simulateTyping(() => {
                // PATCH BIGBAG — Lead faible valeur : prix fixe direct, pas de tunnel
                if (sc.includes("BigBag") || sc.toLowerCase().includes("big bag") || sc.includes("Sac à gravats")) {
                    recordFault('lead_faible_valeur_bigbag');
                    simulateTyping(() => {
                        addMsg("bot", `🪣 <b>BigBag détecté.</b><br><span style='color:var(--text-muted);font-size:11px;'>Solution standardisée — tarif fixe applicable. Livraison + récupération incluses dans votre zone.</span>`);
                        setTimeout(() => {
                            ctrlEl.innerHTML = `
                                <div style="background:rgba(255,184,0,0.08);border:1px solid var(--accent);border-radius:10px;padding:14px;margin-bottom:10px;text-align:center;">
                                    <div style="font-size:10px;color:var(--text-muted);margin-bottom:4px;">TARIF FIXE BIGBAG — TOUT COMPRIS</div>
                                    <div style="font-size:28px;font-weight:900;color:var(--accent);">15 €</div>
                                    <div style="font-size:10px;color:var(--text-muted);">Frais de coordination • Zone ${dataStore.commune || dataStore.region || dataStore.country_name}</div>
                                </div>
                                <button class="pay-btn" onclick="dataStore.precision='BigBag';dataStore.famille='Location &amp; Logistique';askContact();" style="background:var(--accent);color:#000;">RÉSERVER MON BIGBAG — 15€</button>
                            `;
                        }, 500);
                    }, 300);
                    return;
                }
                // BENNE — tunnel volume complet
                if (sc.includes("Benne")) {
                    addMsg("bot", "<b>⚙️ Recherche logistique en cours...</b>");
                    setTimeout(() => {
                        addMsg("bot", "Sélectionnez le volume requis pour verrouiller la solution.");
                        let btns = "";
                        matrixData[dataStore.famille][dataStore.domaine][sc].forEach(p => {
                            btns += `<button class="ui-btn" onclick="handlePrecision('${p}')">${p}</button>`;
                        });
                        ctrlEl.innerHTML = btns;
                    }, 700);
                    return;
                }

                addMsg("bot", "Précisez votre demande pour affiner le diagnostic :");
                let btns = "";
                matrixData[dataStore.famille][dataStore.domaine][sc].forEach(p => {
                    btns += `<button class="ui-btn" onclick="handlePrecision('${p}')">${p}</button>`;
                });
                ctrlEl.innerHTML = btns;
            });
        }

        function handlePrecision(p) {
            dataStore.precision = p;
            addMsg("user", p); ctrlEl.innerHTML = "";
            
            // BASE DE DONNÉES TRINATIONAL — Cartographie officielle des sites par enseigne
            const STORE_MAP = {
                "IKEA": {
                    "BE": ["IKEA Anderlecht (1070)", "IKEA Zaventem (1930)", "IKEA Loncin-Liège (4000)", "IKEA Gentbrugge-Gand (9000)"],
                    "LU": ["IKEA Arlon/Sterpenich (BE-6700)", "IKEA Strassen (LU-8003)"],
                    "CH_Romande":    ["IKEA Aubonne (VD-1170)", "IKEA Vernier/Genève (GE-1214)"],
                    "CH_Alemanique": ["IKEA Dietlikon (ZH-8305)", "IKEA Spreitenbach (AG-8957)", "IKEA Pratteln (BL-4133)", "IKEA Rothenburg (LU-6023)"],
                    "CH_Tessin":     ["IKEA Grancia/Lugano (TI-6916)"]
                },
                "Hornbach": {
                    "BE": ["Hornbach Anderlecht (1070)", "Hornbach Loncin-Liège (4000)", "Hornbach Gand (9000)"],
                    "LU": ["Hornbach Windhof (LU-8399)"],
                    "CH_Romande":    ["Hornbach Aubonne (VD-1170)", "Hornbach Plan-les-Ouates/Genève (GE-1228)"],
                    "CH_Alemanique": ["Hornbach Zürich-Dietlikon (ZH-8305)", "Hornbach Pratteln (BL-4133)", "Hornbach Oberentfelden (AG-5036)", "Hornbach Sursee (LU-6210)"],
                    "CH_Tessin":     ["Hornbach Balerna (TI-6828)"]
                },
                "Brico": {
                    "BE": ["Brico Anderlecht (1070)", "Brico Woluwe (1200)", "Brico Liège (4000)", "Brico Charleroi (6000)", "Brico Namur (5000)"],
                    "LU": ["Brico Livange (LU-3378)", "Brico Strassen (LU-8008)"],
                    "CH_Romande": ["Brico (non disponible — voir Hornbach ou Do it + Garden)"],
                    "CH_Alemanique": ["Brico (non disponible — voir Hornbach)"],
                    "CH_Tessin": ["Brico (non disponible)"]
                },
                "Hubo": {
                    "BE": ["Hubo Anderlecht (1070)", "Hubo Etterbeek (1040)", "Hubo Liège (4000)", "Hubo Namur (5000)"],
                    "LU": ["Hubo Livange (LU-3378)"],
                    "CH_Romande": ["Hubo (non disponible)"],
                    "CH_Alemanique": ["Hubo (non disponible)"],
                    "CH_Tessin": ["Hubo (non disponible)"]
                },
                "Leroy Merlin": {
                    "BE": ["Leroy Merlin Mons (7000)", "Leroy Merlin Charleroi (6000)", "Leroy Merlin Liège (4000)"],
                    "LU": ["Leroy Merlin (non disponible au LU — voir Hornbach)"],
                    "CH_Romande": ["Leroy Merlin (non disponible — voir Hornbach)"],
                    "CH_Alemanique": ["Leroy Merlin (non disponible)"],
                    "CH_Tessin": ["Leroy Merlin (non disponible)"]
                }
            };
            const DEFAULT_BRAND_KEY = "IKEA";

            // Filtre : Protocole Options Logiques (Multi-sites : Vérification Localisation Source)
            const multiSiteBrands = Object.keys(STORE_MAP);
            const matchedBrand = multiSiteBrands.find(b => p.includes(b));
            const isMultiSite = !!matchedBrand;
            
            if (isMultiSite && dataStore.sous_cat && dataStore.sous_cat.includes("Retrait Magasin")) {
                const brand = matchedBrand;
                dataStore.store_brand = brand;
                const brandMap = STORE_MAP[brand] || STORE_MAP[DEFAULT_BRAND_KEY];
                
                if (dataStore.country_code === 'CH') {
                    // SUISSE : Étape régionale intermédiaire obligatoire
                    simulateTyping(() => {
                        addMsg("bot", `<b>📍 Région de retrait ${brand} en Suisse ?</b><br><span style='font-size:11px; color:var(--text-muted);'>Sélectionnez votre région linguistique pour afficher les sites exacts.</span>`);
                        ctrlEl.innerHTML = `
                            <button class="ui-btn" onclick="selectSwissRegion('Romande', '${brand}')" style="border-color:#D52B1E;">🇨🇭 Suisse Romande</button>
                            <button class="ui-btn" onclick="selectSwissRegion('Alemanique', '${brand}')" style="border-color:#D52B1E;">🇨🇭 Suisse Alémanique</button>
                            <button class="ui-btn" onclick="selectSwissRegion('Tessin', '${brand}')" style="border-color:#D52B1E;">🇨🇭 Tessin (Suisse italienne)</button>
                        `;
                    });
                } else {
                    // BE ou LU : Affichage direct des sites
                    const stores = brandMap[dataStore.country_code] || [];
                    simulateTyping(() => {
                        addMsg("bot", `<b>📍 Site ${brand} — Point de départ exact :</b>`);
                        let btns = "";
                        stores.forEach(st => {
                            btns += `<button class="ui-btn" onclick="handleStoreLocation('${st}')">${st}</button>`;
                        });
                        ctrlEl.innerHTML = btns;
                    });
                }
                return;
            }
            
            askUrgence();
        }

        // ÉTAPE RÉGIONALE SUISSE : Romande / Alémanique / Tessin
        function selectSwissRegion(region, brand) {
            dataStore.swiss_region = region;
            addMsg("user", `Suisse ${region}`); ctrlEl.innerHTML = "";
            
            const STORE_MAP = {
                "IKEA": {
                    "CH_Romande":    ["IKEA Aubonne (VD-1170)", "IKEA Vernier/Genève (GE-1214)"],
                    "CH_Alemanique": ["IKEA Dietlikon (ZH-8305)", "IKEA Spreitenbach (AG-8957)", "IKEA Pratteln (BL-4133)", "IKEA Rothenburg (LU-6023)"],
                    "CH_Tessin":     ["IKEA Grancia/Lugano (TI-6916)"]
                },
                "Hornbach": {
                    "CH_Romande":    ["Hornbach Aubonne (VD-1170)", "Hornbach Plan-les-Ouates/Genève (GE-1228)"],
                    "CH_Alemanique": ["Hornbach Zürich-Dietlikon (ZH-8305)", "Hornbach Pratteln (BL-4133)", "Hornbach Oberentfelden (AG-5036)", "Hornbach Sursee (LU-6210)"],
                    "CH_Tessin":     ["Hornbach Balerna (TI-6828)"]
                },
                "Brico": {
                    "CH_Romande": ["Brico non disponible — voir Hornbach ou Do it + Garden"],
                    "CH_Alemanique": ["Brico non disponible — voir Hornbach"],
                    "CH_Tessin": ["Brico non disponible"]
                }
            };
            
            const regionKey = `CH_${region}`;
            const brandMap = STORE_MAP[brand] || STORE_MAP["IKEA"];
            const stores = brandMap[regionKey] || [`${brand} — aucun site confirmé dans cette région`];
            
            simulateTyping(() => {
                addMsg("bot", `<b>📍 Sites ${brand} — Suisse ${region} :</b>`);
                let btns = "";
                stores.forEach(st => {
                    btns += `<button class="ui-btn" onclick="handleStoreLocation('${st}')">${st}</button>`;
                });
                ctrlEl.innerHTML = btns;
            });
        }


        function verifyCustomStore(brand, validStores) {
            const input = document.getElementById('custom-store').value.trim();
            if(!input) return;
            
            addMsg("user", `${brand} ${input}`);
            ctrlEl.innerHTML = "";
            
            simulateTyping(() => {
                // Filtre Malik : Blocage de l'hallucination géographique
                addMsg("bot", `❌ <b>Preuve non localisable.</b> Aucun site ${brand} vérifié à "${input}".<br><span style='font-size:10px;color:var(--text-muted);'>Le système enregistre cette incohérence.</span>`);
                recordFault('localisation_incorrecte');
                
                setTimeout(() => {
                    addMsg("bot", `Souhaitez-vous plutôt sélectionner l'une des options de proximité garanties ?`);
                    let btns = "";
                    validStores.forEach(st => {
                        btns += `<button class="ui-btn" onclick="handleStoreLocation('${st}')">${st}</button>`;
                    });
                    ctrlEl.innerHTML = btns;
                }, 1500);
            });
        }

        function handleStoreLocation(loc) {
            dataStore.store_location = loc;
            addMsg("user", loc); ctrlEl.innerHTML = "";
            
            simulateTyping(() => {
                addMsg("bot", "<b>⚙️ Calcul de l'itinéraire et optimisation des coûts en cours...</b>");
                setTimeout(() => {
                    // PYRAMIDE : Étape 4 — Volume avant Urgence
                    askVolume();
                }, 1500);
            });
        }

        // PYRAMIDE ANTI-GRAVITY — Étape 4 : Volume du chargement
        function askVolume() {
            simulateTyping(() => {
                addMsg("bot", "<b>📦 VOLUME DU CHARGEMENT</b><br>Pour dimensionner le véhicule adapté, précisez le volume à transporter :");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="handleVolume('Petits objets / Colis (< 0.5m³)')">📦 Petits objets / Colis</button>
                    <button class="ui-btn" onclick="handleVolume('Meuble(s) isolé(s) (0.5 – 2m³)')">🛋️ Meuble(s) isolé(s)</button>
                    <button class="ui-btn" onclick="handleVolume('Chargement partiel (2 – 6m³)')">📦 Chargement partiel (fourgon)</button>
                    <button class="ui-btn" onclick="handleVolume('Chargement complet (> 6m³)')">🚚 Chargement complet (camion)</button>
                `;
            });
        }

        function handleVolume(v) {
            dataStore.volume = v;
            addMsg("user", v); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", `✅ Volume verrouillé : <b>${v}</b>. Dimensionnement du véhicule confirmé.`);
                setTimeout(() => askUrgence(), 800);
            });
        }

        function askUrgence() {
            simulateTyping(() => {
                addMsg("bot", "<b>DEGRÉ D'URGENCE ?</b>");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="handleUrgence('Immédiat (Urgence)')" style="border-color:var(--neon-green)">🚀 Immédiat (Surge Pricing)</button>
                    <button class="ui-btn" onclick="handleUrgence('Rendez-vous planifié')">📅 Sur rendez-vous</button>
                `;
            });
        }

        function handleUrgence(u) {
            dataStore.urgence = u;
            updateArbScore('urgence', 20);
            addMsg("user", u); ctrlEl.innerHTML = "";
            
            if (u === 'Rendez-vous planifié') {
                simulateTyping(() => {
                    addMsg("bot", "Veuillez préciser la date et l'heure souhaitées.");
                    ctrlEl.innerHTML = `
                        <input type="datetime-local" id="rdv-time" class="ui-select" style="margin-bottom:10px;">
                        <button class="ui-btn" onclick="submitTime()">Valider le créneau</button>
                    `;
                });
            } else {
                // ÉTAT C→D : Géographie déjà connue — passer directement à la finalisation
                finalizeAfterUrgence();
            }
        }

        function submitTime() {
            const time = document.getElementById('rdv-time').value;
            if(!time) return;
            const formatted = new Date(time).toLocaleString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
            dataStore.date_rendezvous = formatted;
            addMsg("user", formatted);
            finalizeAfterUrgence();
        }

        // ÉTAT C→D : Géographie connue — router vers finalisation sans réinterroger la géographie
        function finalizeAfterUrgence() {
            const isFlash = dataStore.famille === 'Location & Logistique' || dataStore.famille === 'Automobile & Mobilité';
            if (isFlash) {
                askContact();
            } else {
                triggerFinalStep(); // Bâtiment/Énergie : preuve visuelle requise
            }
        }

        function askZip() {
            // Géographie pré-définie : court-circuit direct vers finalisation
            finalizeAfterUrgence();
        }

        function askCountry() {
            simulateTyping(() => {
                addMsg("bot", "<b>⚙️ Géolocalisation de l'IP en cours...</b>");
                
                // Fetch IP Location
                fetch('https://freeipapi.com/api/json')
                    .then(response => response.json())
                    .then(data => {
                        let countryCode = data.countryCode || data.country_code || 'BE';
                        let countryName = "Belgique";
                        
                        if (countryCode === 'CH') countryName = "Suisse";
                        else if (countryCode === 'LU') countryName = "Luxembourg";
                        else {
                            countryCode = 'BE'; 
                            countryName = "Belgique";
                        }
                        
                        // Auto-execute selection
                        gatekeeperAutoDetect(data);
                    })
                    .catch(() => {
                        // Fallback in case of Adblocker / Error
                        forceCountrySelection();
                    });
            });
        }

        function forceCountrySelection() {
            ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", "Veuillez sélectionner votre zone d'intervention manuellement :");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="gatekeeperEntry('BE', 'Belgique')">🇧🇪 Belgique</button>
                    <button class="ui-btn" onclick="gatekeeperEntry('LU', 'Luxembourg')">🇱🇺 Luxembourg</button>
                    <button class="ui-btn" onclick="gatekeeperEntry('CH', 'Suisse')">🇨🇭 Suisse</button>
                `;
            });
        }


        // ── DÉTECTEUR DE DOULEURS — vitrine hero ────────────────────────────
        function captureDouleur() {
            const input = document.getElementById('douleur-input');
            if (!input) return;
            const val = input.value.trim();
            if (val.length < 5) { input.style.borderBottomColor = '#ff4444'; return; }
            dataStore.douleur_brute = val;

            // Cache le formulaire vitrine
            const form = document.getElementById('douleur-form');
            if (form) form.style.display = 'none';

            // Ouvre le chatbot avec le contexte pré-rempli
            openChatbotFlow('prospect');

            // Injecte le besoin brut dans le chat après ouverture
            setTimeout(() => {
                addMsg("user", val);
                addMsg("bot", "<b>📋 Besoin détecté.</b> Je lance l'analyse et la mise en concurrence.<br><span style='font-size:11px;color:var(--text-muted);'>Précisons quelques critères pour garantir des offres fermes.</span>");
                updateArbScore('secteur', 10); // bonus score pour pré-qualification
            }, 800);
        }
        // ── FIN DÉTECTEUR DE DOULEURS ─────────────────────────────────────────

        // ── AGENT 1 : GATEKEEPER ─────────────────────────────────────────
        function gatekeeperEntry(code, name) {
            // Log RGPD consent (timestamp + country)
            dataStore.rgpd_consent = { accepted: true, ts: new Date().toISOString(), country: code };
            // FR : marché actif mais service limité → cap Typeform direct
            if (code === 'FR') {
                addMsg("user", "France");
                ctrlEl.innerHTML = "";
                simulateTyping(() => {
                    addMsg("bot", "🇫🇷 <b>Zone France détectée.</b> Notre déploiement est actif sur les métropoles (Paris, Lyon, Bordeaux, Marseille).<br><span style='color:var(--text-muted);font-size:11px;'>Complétez votre dossier — un conseiller zonal vous recontacte sous 24h pour valider la couverture locale.</span>");
                    ctrlEl.innerHTML = `<button class="pay-btn" onclick="openTypeform({country_name:'France',country_code:'FR'})" style="background:var(--accent);color:#000;">📋 DÉPOSER MON DOSSIER</button>`;
                });
                return;
            }
            selectCountry(code, name, false);
        }

        // ── AGENT 1 : BAN HORS-ZONE (appelé depuis askCountry auto-detect) ──
        function gatekeeperAutoDetect(data) {
            const code = data.countryCode || data.country_code || 'XX';
            const ZONES = ['BE','LU','CH','FR'];
            if (!ZONES.includes(code)) {
                addMsg("bot", "🌐 <b>Zone non couverte.</b><br><span style='color:var(--text-muted);font-size:11px;'>Notre réseau opère sur Belgique, Luxembourg, Suisse et France. Sélectionnez votre pays si vous êtes en zone frontalière.</span>");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="gatekeeperEntry('BE','Belgique')" style="border-color:#FFB800;">🇧🇪 Belgique</button>
                    <button class="ui-btn" onclick="gatekeeperEntry('LU','Luxembourg')" style="border-color:#4EE0D9;">🇱🇺 Luxembourg</button>
                    <button class="ui-btn" onclick="gatekeeperEntry('CH','Suisse')" style="border-color:#D52B1E;">🇨🇭 Suisse</button>
                    <button class="ui-btn" onclick="gatekeeperEntry('FR','France')" style="border-color:#0055A4;">🇫🇷 France</button>
                `;
                return;
            }
            const names = {BE:'Belgique',LU:'Luxembourg',CH:'Suisse',FR:'France'};
            selectCountry(code, names[code] || 'Belgique', true);
        }

        function selectCountry(code, name, isAuto = false) {
            dataStore.country_code = code; try { sessionStorage.setItem('cdm_country', code); sessionStorage.setItem('cdm_country_name', name); } catch(e) {}
            dataStore.country_name = name;
            
            // Set Tax Rate
            if(code === 'CH') dataStore.tva = 0.081;
            else if(code === 'LU') dataStore.tva = 0.17;
            else dataStore.tva = 0.21;
            
            if (!isAuto) addMsg("user", name);
            
            simulateTyping(() => {
                if (isAuto) {
                    addMsg("bot", `📍 Localisation sécurisée : <b>${name}</b>.`);
                }
                
                if (code === 'CH') {
                    addMsg("bot", "🛡️ <b>Protocole LPD chargé</b> (Loi sur la protection des données). Vos données sont stockées en Suisse et cryptées.");
                } else {
                    addMsg("bot", "🛡️ <b>Protocole RGPD chargé</b> (Conformité stricte européenne). Vos données sont cryptées.");
                }
                
                setTimeout(() => {
                    let editLink = isAuto ? ` <a href="#" onclick="forceCountrySelection()" style="color:var(--text-muted); font-size:10px; text-decoration:underline;">[Modifier la zone]</a>` : "";
                    addMsg("bot", `Environnement fiscal verrouillé (TVA applicable : ${dataStore.tva * 100}%).${editLink}`);
                    ctrlEl.innerHTML = "";
                    
                    // MACHINE D'ÉTAT — ROUTAGE POST-PAYS
                    if (dataStore.next_after_country === 'region') {
                        dataStore.next_after_country = null;
                        askRegion();
                    } else if (dataStore.next_after_country === 'precision_retrait') {
                        dataStore.next_after_country = null;
                        proceedToPrecision(dataStore.sous_cat);
                    } else {
                        // Fallback : si pays déjà connu et région non choisie, lancer askRegion
                        if (!dataStore.region) askRegion();
                        else askSecteur();
                    }
                }, 1200);
            }, 800);
        }

        // =============================================================
        // NIVEAU 2 & 3 : Région/Province + Commune (État A→B)
        // =============================================================
        function askRegion() {
            simulateTyping(() => {
                addMsg("bot", `<b>📍 NIVEAU 2 — SECTEUR / PROVINCE.</b><br><span style='color:var(--text-muted);font-size:11px;'>${dataStore.country_name} — Sélectionnez votre région.</span>`);
                let html = "";
                if (dataStore.country_code === 'BE') {
                    html = `
                        <button class="ui-btn" onclick="selectRegion('Bruxelles-Capitale')" style="border-color:#FFB800;">🏠 Bruxelles-Capitale</button>
                        <button class="ui-btn" onclick="selectRegion('Wallonie')" style="border-color:#2ecc71;">🟢 Wallonie</button>
                        <button class="ui-btn" onclick="selectRegion('Flandre')" style="border-color:#3498db;">🔵 Flandre (Vlaanderen)</button>
                    `;
                } else if (dataStore.country_code === 'LU') {
                    html = `<button class="ui-btn" onclick="selectRegion('Grand-Duché')" style="border-color:#4EE0D9;">🇱🇺 Grand-Duché de Luxembourg</button>`;
                } else if (dataStore.country_code === 'CH') {
                    html = `
                        <button class="ui-btn" onclick="selectRegion('Romande')" style="border-color:#D52B1E;">🇨🇭 Suisse Romande</button>
                        <button class="ui-btn" onclick="selectRegion('Alemanique')" style="border-color:#D52B1E;">🇨🇭 Suisse Alémanique</button>
                        <button class="ui-btn" onclick="selectRegion('Tessin')" style="border-color:#D52B1E;">🇨🇭 Tessin (Ticino)</button>
                    `;
                }
                ctrlEl.innerHTML = html;
            });
        }

        function selectRegion(region) {
            dataStore.region = region;
            // Pour la Suisse : stocker la région linguistique (réutilisée par le Protocole Options Logiques)
            if (dataStore.country_code === 'CH') dataStore.swiss_region = region;
            addMsg("user", region); ctrlEl.innerHTML = "";
            askCommuneForRegion(region);
        }

        function askCommuneForRegion(region) {
            const COMMUNES = {
                'Bruxelles-Capitale': [
                    {n:'Bruxelles Centre', z:'1000'}, {n:'Schaerbeek', z:'1030'}, {n:'Ixelles', z:'1050'},
                    {n:'Anderlecht', z:'1070'}, {n:'Molenbeek', z:'1080'}, {n:'Uccle', z:'1180'},
                    {n:'Etterbeek', z:'1040'}, {n:'Saint-Gilles', z:'1060'}, {n:'Evere', z:'1140'}
                ],
                'Wallonie': [
                    {n:'Liège', z:'4000'}, {n:'Namur', z:'5000'}, {n:'Charleroi', z:'6000'},
                    {n:'Mons', z:'7000'}, {n:'Wavre', z:'1300'}, {n:'Arlon', z:'6700'},
                    {n:'Tournai', z:'7500'}, {n:'La Louvière', z:'7100'}
                ],
                'Flandre': [
                    {n:'Gand', z:'9000'}, {n:'Anvers', z:'2000'}, {n:'Bruges', z:'8000'},
                    {n:'Louvain', z:'3000'}, {n:'Hasselt', z:'3500'}, {n:'Courtrai', z:'8500'}
                ],
                'Grand-Duché': [
                    {n:'Luxembourg-Ville', z:'1000'}, {n:'Esch-sur-Alzette', z:'4000'},
                    {n:'Differdange', z:'4500'}, {n:'Pétange', z:'4760'}, {n:'Bettembourg', z:'3250'},
                    {n:'Strassen', z:'8008'}, {n:'Windhof', z:'8399'}
                ],
                'Romande': [
                    {n:'Genève', z:'1200'}, {n:'Lausanne', z:'1000'}, {n:'Sion', z:'1950'},
                    {n:'Neuchâtel', z:'2000'}, {n:'Fribourg', z:'1700'}, {n:'Aubonne', z:'1170'}
                ],
                'Alemanique': [
                    {n:'Zurich', z:'8001'}, {n:'Bâle', z:'4001'}, {n:'Berne', z:'3001'},
                    {n:'St-Gall', z:'9001'}, {n:'Lucerne', z:'6003'}, {n:'Winterthour', z:'8400'}
                ],
                'Tessin': [
                    {n:'Lugano', z:'6900'}, {n:'Bellinzone', z:'6500'}, {n:'Locarno', z:'6600'}
                ]
            };
            const communes = COMMUNES[region] || [];
            simulateTyping(() => {
                addMsg("bot", `<b>📍 NIVEAU 3 — POINT D'ANCRAGE.</b><br><span style='color:var(--text-muted);font-size:11px;'>Commune / Ville d'intervention en ${region}.</span>`);
                let btns = "";
                communes.forEach(c => {
                    btns += `<button class="ui-btn" onclick="geoLockCommune('${c.n}', '${c.z}')">${c.n}</button>`;
                });
                ctrlEl.innerHTML = btns;
            });
        }

        function geoLockCommune(name, cp) {
            dataStore.commune = name;
            dataStore.cp = cp;
            updateArbScore('geo', 20);
            addMsg("user", name); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", `<span style='color:var(--neon-green);font-size:12px; font-weight:900;'>✅ Zone d'arbitrage verrouillée</span><br><b>${dataStore.country_name} → ${dataStore.region} → ${name} (${cp})</b>`);
                addMsg("bot", "<span style='color:var(--text-muted);font-size:11px;'>Prestataires certifiés disponibles dans ce secteur. Identifiez votre besoin pour lancer la mise en concurrence.</span>");
                setTimeout(() => askSecteur(), 800);
            });
        }

        // askCity() maintenu pour compatibilité descendante (flux non-prospect)
        function askCity() {
            if (dataStore.region) { askSecteur(); return; }
            askSecteur(); // fallback
        }

        // SECTEUR : affiché après détection du pays
        function askSecteur() {

            simulateTyping(() => {
                addMsg("bot", `<b>📦 ${(DICTS[_lang]||DICT_FR).step_sector}</b><br><span style='color:var(--text-muted);font-size:11px;'>${(DICTS[_lang]||DICT_FR).step_sector_sub}</span>`);
                let html = `<select class="ui-select" onchange="handleSecteur(this.value)">
                    <option value="">-- Sélectionner un secteur --</option>`;
                Object.keys(matrixData).forEach(k => html += `<option value="${k}">${k}</option>`);
                ctrlEl.innerHTML = html + `</select>`;
            });
        }

        // MODULE BIG BANG AUTOMOBILE
        function handleBigBangCountry(code, name) {
            dataStore.country_code = code;
            dataStore.country_name = name;
            if(code === 'CH') dataStore.tva = 0.081;
            else if(code === 'LU') dataStore.tva = 0.17;
            else dataStore.tva = 0.21;
            addMsg("user", name); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", `🛡️ Zone verrouillée : <b>${name}</b> — TVA ${dataStore.tva * 100}%`);
                addMsg("bot", "<b>Type de recherche :</b>");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="handleBigBangType('Achat VO occasion')">🚗 Achat VO (occasion)</button>
                    <button class="ui-btn" onclick="handleBigBangType('Import Véhicule neuf')">🏎️ Import Neuf (cross-border)</button>
                    <button class="ui-btn" onclick="handleBigBangType('Sourcing + Convoyage')">🚛 Sourcing + Convoyage</button>
                    <button class="ui-btn" onclick="handleBigBangType('Expertise / Contre-expertise')">📋 Expertise Sinistre</button>
                `;
            });
        }

        function handleBigBangType(t) {
            dataStore.bb_type = t;
            addMsg("user", t); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", "<b>Budget de transaction :</b>");
                ctrlEl.innerHTML = `
                    <button class="ui-btn" onclick="handleBigBangBudget('< 5 000 €', 0)">< 5 000 €</button>
                    <button class="ui-btn" onclick="handleBigBangBudget('5 000 – 15 000 €', 10)">5 000 – 15 000 €</button>
                    <button class="ui-btn" onclick="handleBigBangBudget('15 000 – 30 000 €', 10)">15 000 – 30 000 €</button>
                    <button class="ui-btn" onclick="handleBigBangBudget('> 30 000 €', 10)">> 30 000 €</button>
                `;
            });
        }

        function handleBigBangBudget(budget, commRate) {
            dataStore.bb_budget = budget;
            dataStore.bb_commission = commRate;
            addMsg("user", budget); ctrlEl.innerHTML = "";
            simulateTyping(() => {
                const commMsg = commRate > 0
                    ? `📌 Dossier qualifié — Activation du sourcing prioritaire.`
                    : `📌 Budget < 1 000€ — Frais fixes applicables.`;
                addMsg("bot", commMsg);
                addMsg("bot", "<b>Pour activer le sourcing inversé, des frais de dossier s'appliquent.</b><br><span style='color:var(--text-muted); font-size:11px;'>Non remboursables. Garantissent la mobilisation de notre réseau tri-pays.</span>");
                setTimeout(() => {
                    ctrlEl.innerHTML = `
                        <div style="background:rgba(212,175,55,0.1); border:1px solid var(--gold); border-radius:10px; padding:15px; margin-bottom:10px;">
                            <div style="font-size:11px; color:var(--text-muted); margin-bottom:5px;">FRAIS D'ACTIVATION DU SOURCING</div>
                            <div style="font-size:28px; font-weight:900; color:var(--gold);">25 €</div>
                            <div style="font-size:10px; color:var(--text-muted);">Dossier technique • Sourcing ${dataStore.country_name} • TVA ${dataStore.tva*100}%</div>
                        </div>
                        <button class="pay-btn" onclick="handleBigBangPayDossier()" style="background:var(--gold); color:#000; font-size:12px;">🚨 ACTIVER LE SOURCING — 25€</button>
                    `;
                }, 1000);
            });
        }

        function handleBigBangPayDossier() {
            ctrlEl.innerHTML = `<div style="text-align:center; padding:10px; color:var(--gold)">⚙️ Activation du réseau tri-pays...</div>`;
            playBeep(880, 0.15);
            setTimeout(() => {
                addMsg("bot", `✅ <b>Sourcing activé.</b> Dossier ouvert — Réf. BB-${Date.now().toString(36).toUpperCase().slice(-6)}.`);
                addMsg("bot", `🔍 Scan en cours sur <b>${dataStore.country_name}</b> pour : <b>${dataStore.bb_type}</b> | Budget : <b>${dataStore.bb_budget}</b>.`);
                simulateTyping(() => {
                    addMsg("bot", "<b>Coordonnées de contact :</b>");
                    ctrlEl.innerHTML = `
                        <div class="compact-row">
                            <input type="tel" id="bb-tel" class="ui-select" placeholder="GSM / Natel">
                            <input type="email" id="bb-email" class="ui-select" placeholder="Email">
                        </div>
                        <button class="ui-btn" onclick="submitBigBang()" style="background:var(--gold); color:#000;">FINALISER LE DOSSIER</button>
                    `;
                });
            }, 2000);
        }

        function submitBigBang() {
            const tel = document.getElementById('bb-tel')?.value;
            const email = document.getElementById('bb-email')?.value;
            if(!tel || !email) { alert("Renseignez vos coordonnées pour finaliser."); return; }
            dataStore.tel = tel; dataStore.email = email;
            addMsg("user", `Contact : ${email}`);
            ctrlEl.innerHTML = "";
            simulateTyping(() => {
                addMsg("bot", `🏆 <b>DOSSIER BIG BANG VERROUILLÉ.</b>`);
                addMsg("bot", `Notre courtier réseau prend en charge votre recherche <b>${dataStore.bb_type}</b> sur <b>${dataStore.country_name}</b>.`);
                addMsg("bot", `📧 Un email de confirmation est envoyé à <b>${email}</b>. Rappel sous 24h.`);
                if(dataStore.bb_commission > 0) {
                    addMsg("bot", `<span style='color:var(--gold); font-size:11px;'>📊 Commission ${dataStore.bb_commission}% applicable sur transaction confirmée — document signé à réception.</span>`);
                }
                ctrlEl.innerHTML = `<button class="ui-btn" onclick="location.reload()" style="background:var(--gold);color:#000;">NOUVELLE RECHERCHE</button>`;
                playBeep(1200, 0.3);
            });
        }



        function selectCommune(city) {
            addMsg("user", city);
            simulateTyping(() => {
                addMsg("bot", `Sélectionnez votre commune ou quartier à <b>${city}</b> :`);
                const mapping = {
                    'Bruxelles': [
                        {n: 'Schaerbeek', z: '1030'}, {n: 'Ixelles', z: '1050'}, {n: 'Uccle', z: '1180'}, 
                        {n: 'Anderlecht', z: '1070'}, {n: 'Jette', z: '1090'}, {n: 'Etterbeek', z: '1040'},
                        {n: 'Saint-Gilles', z: '1060'}, {n: 'Evere', z: '1140'}, {n: 'Forest', z: '1190'}
                    ],
                    'Liège': [{n: 'Liège Centre', z: '4000'}, {n: 'Angleur', z: '4031'}, {n: 'Herstal', z: '4040'}],
                    'Charleroi': [{n: 'Charleroi Centre', z: '6000'}, {n: 'Gilly', z: '6060'}, {n: 'Gosselies', z: '6041'}],
                    'Namur': [{n: 'Namur Centre', z: '5000'}, {n: 'Jambes', z: '5100'}],
                    'Mons': [{n: 'Mons Centre', z: '7000'}, {n: 'Jemappes', z: '7012'}],
                    'Wavre': [{n: 'Wavre Centre', z: '1300'}, {n: 'Louvain-la-Neuve', z: '1348'}],
                    
                    'Luxembourg-Ville': [{n: 'Ville-Haute', z: '1000'}, {n: 'Gare', z: '1001'}],
                    'Esch-sur-Alzette': [{n: 'Esch Centre', z: '4000'}],
                    'Differdange': [{n: 'Differdange Centre', z: '4500'}],
                    
                    'Genève': [{n: 'Eaux-Vives', z: '1207'}, {n: 'Plainpalais', z: '1205'}],
                    'Lausanne': [{n: 'Ouchy', z: '1006'}, {n: 'Flon', z: '1003'}],
                    'Neuchâtel': [{n: 'Neuchâtel Centre', z: '2000'}],
                    'Fribourg': [{n: 'Fribourg Centre', z: '1700'}]
                };
                
                let btns = "";
                mapping[city].forEach(c => {
                    btns += `<button class="ui-btn" onclick="finalizeZone('${c.n}', '${c.z}')">${c.n} / ${c.z}</button>`;
                });
                ctrlEl.innerHTML = btns;
            });
        }

        function finalizeZone(commune, zip) {
            dataStore.cp = zip;
            dataStore.commune = commune;
            addMsg("user", `${commune} (${zip})`);
            ctrlEl.innerHTML = "";
            
            const localite = commune;
            
            // 1. Analyse Technique & Filtrage de Pertinence (Mode Expert 2026)
            const subventionnes = [
                'Isolation & Toiture', 'Chauffage & Pompe à chaleur', 
                'Châssis & Fenêtres', 'Solaire Photovoltaïque', 
                'Audit Énergétique'
            ];

            const justInTime = [
                'Location & Logistique', 'Serrurerie', 'Dépannage Électrique', 'Plomberie d\'Urgence'
            ];
            
            const estEligible = subventionnes.includes(dataStore.domaine);
            const isFlash = justInTime.includes(dataStore.domaine) || justInTime.includes(dataStore.famille);

            simulateTyping(() => {
                if (isFlash) {
                    addMsg("bot", `<b>Zone Elite ${commune} confirmée.</b> Bloquez votre créneau d'intervention immédiat.`);
                    dataStore.price = 5;
                    setTimeout(() => askContact(), 1000);
                } 
                else if (estEligible) {
                    const source = zip.startsWith('1') ? 'Primes RENOLUTION (Bruxelles)' : 'Primes Habitation (Wallonie / RGE)';
                    addMsg("bot", `Diagnostic Éligibilité : Secteur <b>${commune}</b>.`);
                    addMsg("bot", `Le dispositif <b>${source}</b> est pleinement actif dans votre zone. Ces travaux ouvrent droit à des subventions majeures.`);
                    setTimeout(() => {
                        addMsg("bot", "Souhaitez-vous inclure le <b>Dossier Technique Certifié (250€)</b> pour garantir votre prime ?");
                        ctrlEl.innerHTML = `
                            <button class="ui-btn" onclick="handlePack(true)" style="border-color:var(--accent)">✅ Inclure le Dossier (Elite)</button>
                            <button class="ui-btn" onclick="handlePack(false)">❌ Expert uniquement</button>
                        `;
                    }, 1500);
                }
                else {
                    addMsg("bot", `Analyse locale : <b>${commune}</b>.`);
                    if (['Peinture', 'Nettoyage'].includes(dataStore.domaine)) {
                         addMsg("bot", "Disponibilité immédiate confirmée. Lancement du scan prestataire.");
                    } else {
                         addMsg("bot", `Nous avons identifié des experts certifiés disponibles à <b>${commune}</b>.`);
                    }
                    setTimeout(() => askProof(), 1200);
                }
            });
        }

        function handlePack(choice) {
            dataStore.pack_primes = choice;
            addMsg("user", choice ? "Pack Sérénité inclus" : "Expert uniquement");
            ctrlEl.innerHTML = "";
            askProof();
        }

        function askProof() {
            simulateTyping(() => {
                let exigences = "Une preuve visuelle claire de la zone d'intervention";
                const d = dataStore.famille || dataStore.domaine || "";
                if (d.includes('Toiture')) exigences = "Photo détaillée de la pente, de l'accès au toit, et type de tuiles visibles";
                else if (d.includes('Plomberie')) exigences = "Photo nette de la fuite/installation, avec diamètre des tuyaux visible";
                else if (d.includes('Serrurerie')) exigences = "Photo du cylindre et de la tranche de la porte";
                else if (d.includes('Énergies')) exigences = "Photo de l'emplacement prévu et du tableau électrique ouvert";
                else if (d.includes('Maçonnerie')) exigences = "Dimensions exactes et photo de la structure porteuse";
                
                addMsg("bot", `🛑 <b>PRÉREQUIS TECHNIQUES OBLIGATOIRES</b><br>L'analyse est suspendue dans l'attente de données fiables. Pas de données = Pas de solution.<br>Veuillez impérativement fournir :<br>- <b>${exigences}</b>.`);
                ctrlEl.innerHTML = `
                    <div class="drop-zone" onclick="document.getElementById('capture_ip2').click()">📷 Uploader le visuel requis</div>
                    <input type="file" id="capture_ip2" style="display:none" onchange="triggerFinalStep()">
                `;
            });
        }

        function triggerFinalStep() {
            const fileInput = document.getElementById('capture_ip2') || document.getElementById('s-photo-elec');
            const file = fileInput ? fileInput.files[0] : null;
            const isFlashLogistics = (dataStore.famille === 'Location & Logistique') || (dataStore.famille === 'Automobile & Mobilité');
            
            if (!isFlashLogistics) addMsg("user", "Preuve visuelle transmise.");
            ctrlEl.innerHTML = "";
            
            simulateTyping(() => {
                if (!isFlashLogistics) addMsg("bot", "<b>Analyse des métadonnées en cours...</b>");
                
                setTimeout(() => {
                    if (!isFlashLogistics) {
                        // 1. Analyse de cohérence Vision IA
                        let isSuspicious = false;
                        if (file) {
                            const name = file.name.toLowerCase();
                            if (file.size < 40000 || name.includes('logo') || name.includes('icon') || name.includes('avatar')) {
                                isSuspicious = true;
                            }
                        }

                        if (isSuspicious) {
                            addMsg("bot", "❌ <b>Visuel non conforme.</b> Le fichier soumis ne correspond pas aux exigences techniques.");
                            if (recordFault('visuel_non_conforme')) return; // Double Faute → escalade
                            setTimeout(() => {
                                ctrlEl.innerHTML = `<button class="ui-btn" onclick="askProof()">Soumettre un visuel conforme</button>`;
                            }, 700);
                            return;
                        }

                        // MULTI-AGENT ORCHESTRATION (Invisible pour le client)
                        addMsg("bot", "<b>⚙️ Analyse technique en cours...</b> (Scan des disponibilités et de la conformité)");
                        if (dataStore.country_code === 'LU') {
                            addMsg("bot", "🇱🇺 <i>Vérification des disponibilités matérielles (Grande Région).</i>");
                        }

                        setTimeout(() => {
                            addMsg("bot", "<b>⚙️ Validation de la conformité locale</b>" + (dataStore.country_code === 'CH' ? ' (SIA)' : (dataStore.country_code === 'LU' ? ' (LENOZ)' : '')) + " et verrouillage de la solution...");
                            
                            setTimeout(() => {
                                // Calcul Fantôme (Strictement invisible pour le client)
                                const estimates = { 'Toiture': 4500, 'Peinture': 1200, 'Chauffage': 3500, 'Solaire': dataStore.solaire_cout_inst || 8000, 'Solaire Photovoltaïque': dataStore.solaire_cout_inst || 8000 };
                                let D = estimates[dataStore.domaine]; 
                                
                                if (D) {
                                    const taux = D < 1000 ? 0.15 : 0.10;
                                    const B = Math.floor(D * taux); 
                                    dataStore.estimate_D = D;
                                    dataStore.commission_B = B;
                                    
                                    const badgeHtml = getInterventionBadge(dataStore.country_code, dataStore.famille, dataStore.domaine, dataStore.sous_cat);
                                    addMsg("bot", `✅ <b>Analyse confirmée. Solution prête.</b><br>${badgeHtml}`);
                                    addMsg("bot", `L'intervention est validée et prête à être planifiée.`);
                                    setTimeout(() => askContact(), 2000);
                                } else {
                                    // Escalade : Appel d'Offres Interne (Invisible pour le client)
                                    addMsg("bot", "<b>⚙️ Traitement avancé : Synthèse de la solution...</b>");
                                    
                                    setTimeout(() => {
                                        // Simulation Back-Office : Algorithme de Sélection (Note > Réactivité > Prix)
                                        D = 1850; // Chiffrage issu de l'appel d'offres gagnant
                                        const taux = D < 1000 ? 0.15 : 0.10;
                                        dataStore.estimate_D = D;
                                        dataStore.commission_B = Math.floor(D * taux);
                                        
                                        const badgeHtml2 = getInterventionBadge(dataStore.country_code, dataStore.famille, dataStore.domaine, dataStore.sous_cat);
                                        addMsg("bot", `✅ <b>Solution sur-mesure validée.</b><br>${badgeHtml2}`);
                                        addMsg("bot", `L'intervention est qualifiée et sécurisée.`);
                                        setTimeout(() => askContact(), 2000);
                                    }, 2500);
                                }
                            }, 1500);
                        }, 1500);
                    } else {
                        setTimeout(() => askContact(), 1000);
                    }
                }, isFlashLogistics ? 0 : 2000);
            });
        }

        function askContact() {
            // TYPEFORM FIRST — qualification obligatoire avant paiement Stripe
            simulateTyping(() => {
                addMsg("bot", `<b>${(DICTS[_lang]||DICT_FR).step_contact}</b><br><span style='color:var(--text-muted);font-size:11px;'>${(DICTS[_lang]||DICT_FR).step_contact_sub}</span>`);
                setTimeout(() => {
                    let phonePlaceholder = "Votre Portable";
                    if(dataStore.country_code === 'CH') phonePlaceholder = "Votre Natel";
                    else if(dataStore.country_code === 'BE') phonePlaceholder = "Votre GSM";

                    ctrlEl.innerHTML = `
                        <div class="compact-row">
                            <input type="tel" id="c-tel" class="ui-select" placeholder="${phonePlaceholder}" value="${dataStore.tel || ''}">
                            <input type="email" id="c-email" class="ui-select" placeholder="Votre Email" value="${dataStore.email || ''}">
                        </div>
                        <div style="font-size:9px; color:var(--text-muted); margin-bottom:10px; text-align:center;">
                            🔒 En finalisant, vous acceptez nos <a href="#" style="color:var(--accent);">CGV</a> et la <a href="#" style="color:var(--accent);">Politique de Confidentialité</a> — Norme ${dataStore.country_code === 'CH' ? 'LPD Suisse' : 'RGPD UE'}.
                        </div>
                        <button class="pay-btn" onclick="validateContactAndOpenTypeform()" style="background:var(--accent); color:#000;">
                            📋 VALIDER MON DOSSIER — Étape 1/2
                        </button>
                        <div style="text-align:center;margin-top:10px;">
                            <a href="https://tally.so/r/KY8dzg" target="_blank" rel="noopener"
                                style="font-size:10px;color:rgba(255,255,255,0.35);text-decoration:none;border-bottom:1px solid rgba(255,255,255,0.15);padding-bottom:1px;">
                                Problème technique ? Formulaire de secours →
                            </a>
                        </div>
                    `;
                }, 400);
            });
        }

        const _BURNER_DOMAINS = ["mailinator", "tempmail", "yopmail", "guerrillamail", "throwam", "sharklasers", "spam4", "trashmail", "fakeinbox", "maildrop", "dispostable", "mailnull", "spamgourmet", "mytemp", "temp-mail", "tempr.email", "burnermail", "disposablemail", "getnada", "mailnesia", "10minutemail", "minutemail", "mohmal", "spambox", "spamfree24", "wegwerfmail", "crazymailing", "sogetthis", "armyspy", "dayrep"];

        function _isBurnerEmail(email) {
            const domain = email.split('@')[1]?.toLowerCase() || '';
            return _BURNER_DOMAINS.some(d => domain.includes(d));
        }

        function validateContactAndOpenTypeform() {
            const tel   = document.getElementById('c-tel').value;
            const email = document.getElementById('c-email').value.trim().toLowerCase();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!tel || tel.length < 8)            { alert("Numéro de téléphone invalide."); return; }
            if (!email || !emailRegex.test(email)) { alert("Email invalide."); return; }
            if (_isBurnerEmail(email)) {
                recordFault('email_jetable');
                addMsg("bot", "❌ <b>Email temporaire détecté.</b><br><span style='font-size:11px;color:var(--text-muted);'>Les adresses jetables ne sont pas acceptées. Utilisez votre email professionnel ou personnel pour recevoir la confirmation d'intervention.</span>");
                return;
            }

            dataStore.tel   = tel;
            dataStore.email = email;
            updateArbScore('contact', 20);
            addMsg("user", `Contact : ${email}`);
            ctrlEl.innerHTML = "";

            simulateTyping(() => {
                addMsg("bot", "<b>✅ Coordonnées enregistrées.</b> Ouvrez le formulaire de qualification pour finaliser votre dossier d'arbitrage. <span style='color:var(--text-muted);font-size:10px;'>(90 secondes)</span>");
                ctrlEl.innerHTML = `
                    <button class="pay-btn" onclick="openTypeformThenPay()" style="background:var(--accent); color:#000; margin-bottom:8px;">
                        📋 OUVRIR LE FORMULAIRE DE QUALIFICATION — Étape 1/2
                    </button>
                    <button class="ui-btn" onclick="showFinalRecap()" style="font-size:10px; opacity:0.45;">
                        Passer cette étape
                    </button>
                `;
            }, 300);
        }

        function openTypeformThenPay() {
            // Ouvre Typeform ; onSubmit déclenche showFinalRecap automatiquement
            dataStore._typeform_completed = false;
            openTypeform(dataStore, function onTypeformDone() {
                dataStore._typeform_completed = true; updateArbScore('typeform', 20);
                closeTypeform();
                simulateTyping(() => {
                    addMsg("bot", "✅ <b>Dossier de qualification validé.</b> Passez maintenant à la sécurisation de votre intervention.");
                    showFinalRecap();
                }, 300);
            });
        }

        function validateContact() {
            const tel = document.getElementById('c-tel').value;
            const email = document.getElementById('c-email').value.trim().toLowerCase();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!tel || tel.length < 8) { alert("Numéro de téléphone invalide."); return; }
            if(!email || !emailRegex.test(email)) { alert("Email invalide."); return; }
            if(_isBurnerEmail(email)) { recordFault('email_jetable'); addMsg("bot","❌ <b>Email temporaire refusé.</b> Renseignez votre email permanent."); return; }
            
            dataStore.tel = tel; dataStore.email = email;
            addMsg("user", `Contact validé : ${email}`);
            ctrlEl.innerHTML = "";
            showFinalRecap();
        }

        function showFinalRecap() {
            simulateTyping(() => {
                let basePrice = 15;
                let isUrgent = dataStore.urgence === 'Immédiat (Urgence)';

                if (dataStore.famille === 'Location & Logistique') {
                    basePrice = 5;
                }

                if (isUrgent) {
                    basePrice = 25;
                } else {
                    // Restriction horaire supprimée — accès 24h/24
                }

                // BOUCLIER D'AFFILIATION — déduction crédit si email reconnu
                let creditApplied = 0;
                if (dataStore.affiliation_credit && dataStore.affiliation_credit.email === dataStore.email) {
                    creditApplied = Math.min(dataStore.affiliation_credit.amount, basePrice);
                    basePrice = Math.max(0, basePrice - creditApplied);
                    dataStore.affiliation_credit = null; // consommé
                }

                const totalPrice = basePrice + (dataStore.pack_primes ? 250 : 0);
                
                let creditLine = creditApplied > 0 ? `<br><span style='color:var(--gold);font-size:11px;'>🎁 Crédit Coup d'Main appliqué : -${creditApplied}€</span>` : '';
                let detailTexte = isUrgent ? `Frais de réservation prioritaire : ${basePrice}€` : `Frais de sécurisation : ${basePrice}€`;

                addMsg("bot", `<b>🏆 RÉSULTAT DE L'ARBITRAGE</b><br><span style='color:var(--text-muted);font-size:11px;'>Frais de sécurisation de votre dossier — garantit la mobilisation prioritaire de notre réseau.</span><br>${detailTexte}${creditLine}<br>${dataStore.pack_primes ? 'Pack Sérénité : 250€<br>' : ''}TOTAL : <b>${totalPrice}€</b>`);
                addMsg("bot", `Notre moteur a sélectionné les prestataires les plus compétitifs sur <b>${dataStore.commune || dataStore.region || dataStore.country_name || "votre zone"}</b>. Sécurisez votre accès en priorité.`);
                
                let btnTexte = isUrgent ? `🚨 RÉSERVATION PRIORITAIRE — ${totalPrice}€` : `✅ ÉTAPE 1 : SÉCURISER LE MATÉRIEL`;
                const isAuto = dataStore.famille === 'Automobile & Mobilité';
                if (isAuto) btnTexte = isUrgent ? `🚨 DÉPANNAGE IMMÉDIAT — ${totalPrice}€` : `✅ PLANIFIER L'INTERVENTION`;

                ctrlEl.innerHTML = `<button class="pay-btn" onclick="triggerPaymentStep1(${totalPrice})" ${isUrgent ? 'style="background:var(--accent); color:#000;"' : ''}>${btnTexte}</button>`;
            }, 1200);
        }


        // ── AGENT 4 : TRÉSORIER — Stripe Shield + Anti-Fraude ───────────────
        const _fraudLog = { attempts: 0, lastAttempt: null, banned: false };

        function stripeShield(amount, onPass) {
            // Check ban
            if (_fraudLog.banned) {
                addMsg("bot", "🚫 <b>Accès refusé.</b> Activité suspecte détectée sur cette session. Contactez support@agpgroup.be.");
                return;
            }
            // Validate amount is a real number in expected range
            const VALID_AMOUNTS = [5, 15, 25, 49, 250, 275];
            if (!amount || isNaN(amount) || !VALID_AMOUNTS.includes(Number(amount))) {
                _fraudLog.attempts++;
                _fraudLog.lastAttempt = Date.now();
                if (_fraudLog.attempts >= 3) {
                    _fraudLog.banned = true;
                    addMsg("bot", "🚫 <b>Session bloquée.</b> Tentatives de fraude détectées. Référence : FRD-" + Date.now().toString(36).toUpperCase());
                    ctrlEl.innerHTML = "";
                }
                console.error('[TRÉSORIER] Montant invalide:', amount);
                return;
            }
            _fraudLog.attempts = 0;
            onPass(amount);
        }
        // ── AGENT 2B : SCANCONFORMITÉ — Rapport auto + affiliation ────────
        const AFFILIATION_LINK = 'https://REMPLACE_PAR_TON_LIEN_AFFILIATION'; // ton lien partenaire

        function generateConformiteReport(data) {
            const ref   = data.ref   || 'CDM-' + Date.now().toString(36).toUpperCase().slice(-6);
            const pays  = data.pays  || dataStore.country_name || 'N/A';
            const norm  = (dataStore.country_code === 'CH') ? 'LPD Suisse' : 'RGPD UE 2016/679';
            const score = Math.min(100, Object.values(ARB_SCORE).reduce((a,b) => a+b, 0));
            const ts    = new Date().toLocaleString('fr-FR');

            return {
                ref, pays, norme: norm, score,
                secteur:  dataStore.famille  || 'N/A',
                domaine:  dataStore.domaine  || 'N/A',
                urgence:  dataStore.urgence  || 'N/A',
                montant:  data.montant       || 'N/A',
                affiliation_link: AFFILIATION_LINK,
                generated_at: ts,
                rgpd_consent: dataStore.rgpd_consent || null,
            };
        }

        function displayConformiteReport(report) {
            const scoreColor = report.score >= 80 ? '#00ff66' : report.score >= 50 ? '#FFB800' : '#aaa';
            addMsg("bot", `
                <div style="background:rgba(0,255,102,0.04);border:1px solid rgba(0,255,102,0.15);border-radius:12px;padding:14px;margin-top:8px;font-size:10px;line-height:1.8;">
                    <div style="font-size:9px;letter-spacing:3px;color:var(--text-muted);margin-bottom:8px;">RAPPORT DE CONFORMITÉ · ${report.ref}</div>
                    <div>📍 <b>Pays :</b> ${report.pays} &nbsp;·&nbsp; Norme : <b>${report.norme}</b></div>
                    <div>📦 <b>Secteur :</b> ${report.secteur} — ${report.domaine}</div>
                    <div>💶 <b>Montant :</b> ${report.montant}</div>
                    <div>🔒 <b>Consentement RGPD :</b> ${report.rgpd_consent ? '✅ Loggé ' + report.rgpd_consent.ts : '⚠️ Non loggé'}</div>
                    <div style="margin-top:6px;">📊 <b>Score dossier :</b> <span style="color:${scoreColor};font-weight:900;">${report.score}%</span></div>
                    <div style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.06);">
                        <a href="${report.affiliation_link}" target="_blank" rel="noopener"
                            style="color:var(--accent);font-weight:700;font-size:9px;text-decoration:none;">
                            🔗 Accéder au service partenaire recommandé →
                        </a>
                    </div>
                    <div style="font-size:8px;color:rgba(255,255,255,0.2);margin-top:4px;">Généré le ${report.generated_at}</div>
                </div>
            `);
        }
        // ── FIN SCANCONFORMITÉ ───────────────────────────────────────────────

        // ── FIN AGENT 4 ──────────────────────────────────────────────────────

        // ─── VRAI PAIEMENT STRIPE ─────────────────────────────────────────────
        function sendLeadEmail(templateParams) {
            if (typeof emailjs === 'undefined' ||
                EMAILJS_SERVICE_ID === 'service_REMPLACE') {
                console.warn('[EmailJS] Non configuré — lead non envoyé');
                return Promise.resolve();
            }
            return emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams)
                .catch(err => console.error('[EmailJS] Erreur:', err));
        }

        function launchStripePayment(amount) {
            const link = STRIPE_PAYMENT_LINKS[amount] || STRIPE_PAYMENT_LINKS['default'];

            if (!link || link.includes('REMPLACE')) {
                console.warn('[Stripe] Non configuré — simulation activée');
                setTimeout(() => onPaymentSuccess(amount), 1500);
                return;
            }

            // Génère une ref unique liée à cette session
            const ref   = 'CDM-' + Date.now().toString(36).toUpperCase().slice(-6);
            const email = encodeURIComponent(dataStore.email || '');
            const url   = `${link}?prefilled_email=${email}&client_reference_id=${encodeURIComponent(ref)}`;
            dataStore._pending_ref    = ref;
            dataStore._pending_amount = amount;

            window.open(url, '_blank');

            addMsg("bot", `💳 <b>Terminal de paiement sécurisé ouvert</b> — ${amount}€<br><span style='font-size:11px;color:var(--text-muted);'>Finalisez dans la fenêtre Stripe. La confirmation est automatique.</span>`);

            // Indicateur de polling
            ctrlEl.innerHTML = `
                <div id="poll-status" style="text-align:center;padding:14px;">
                    <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px;">
                        ⏳ En attente de confirmation bancaire…
                    </div>
                    <div style="font-size:9px;color:rgba(255,255,255,0.2);">Ref : ${ref}</div>
                </div>
                <button class="ui-btn" onclick="launchStripePayment(${amount})" style="font-size:10px;opacity:0.45;margin-top:4px;">
                    🔄 Rouvrir la fenêtre de paiement
                </button>
            `;

            // Polling réel vers Vercel /api/check-payment
            pollPaymentConfirmation(ref, amount);
        }

        function pollPaymentConfirmation(ref, amount) {
            // Pas de Vercel configuré → fallback bouton manuel
            if (!VERCEL_API_BASE || VERCEL_API_BASE.includes('REMPLACE')) {
                document.getElementById('poll-status').innerHTML = `
                    <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">
                        Webhook non configuré — confirmez manuellement après paiement.
                    </div>`;
                const btn = document.createElement('button');
                btn.className = 'ui-btn';
                btn.style.cssText = 'border-color:var(--neon-green);color:var(--neon-green);';
                btn.textContent = '✅ Paiement effectué — Confirmer';
                btn.onclick = () => onPaymentSuccess(amount);
                document.getElementById('poll-status').after(btn);
                return;
            }

            let attempts = 0;
            const MAX    = 40;   // 40 × 3s = 2 min max
            const DELAY  = 3000;

            const poll = async () => {
                if (attempts >= MAX) {
                    // Timeout — affiche bouton de contact
                    const el = document.getElementById('poll-status');
                    if (el) el.innerHTML = `
                        <div style="font-size:11px;color:var(--accent);">
                            ⚠️ Confirmation non reçue après 2 min.<br>
                            <a href="mailto:contact@agpgroup.be?subject=Paiement CDM ${ref}" style="color:var(--accent);">
                                Contactez-nous avec la réf. ${ref}
                            </a>
                        </div>`;
                    return;
                }
                attempts++;

                try {
                    const r = await fetch(
                        `${VERCEL_API_BASE}/api/check-payment?ref=${encodeURIComponent(ref)}`,
                        { cache: 'no-store' }
                    );
                    const data = await r.json();

                    if (data.paid) {
                        // ✅ Paiement confirmé côté Stripe — déclenche le succès
                        onPaymentSuccess(data.amount ? parseFloat(data.amount) : amount);
                        return;
                    }
                } catch (e) {
                    console.warn('[Poll] Erreur réseau:', e.message);
                }

                // Mise à jour du compteur visible
                const el = document.getElementById('poll-status');
                if (el) {
                    const dot = '.'.repeat((attempts % 3) + 1);
                    el.innerHTML = `
                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px;">
                            ⏳ Attente confirmation bancaire${dot}<br>
                            <span style="font-size:9px;opacity:0.5;">${attempts}/${MAX} vérifications — Ref : ${ref}</span>
                        </div>`;
                }

                setTimeout(poll, DELAY);
            };

            setTimeout(poll, DELAY); // Premier check après 3s
        }

        function onPaymentSuccess(amount) {
            playBeep(1200, 0.3);
            ctrlEl.innerHTML = '';

            // Envoi du lead par email (EmailJS)
            const leadData = {
                to_email:    LEADS_EMAIL,
                from_name:   "Coup d'main — Terminal",
                subject:     `[LEAD PAYANT] ${dataStore.famille || 'Intervention'} — ${amount}€`,
                pays:        dataStore.country_name  || 'N/A',
                region:      dataStore.region        || 'N/A',
                commune:     dataStore.commune       || dataStore.cp || 'N/A',
                secteur:     dataStore.famille       || 'N/A',
                domaine:     dataStore.domaine       || 'N/A',
                sous_cat:    dataStore.sous_cat      || 'N/A',
                urgence:     dataStore.urgence       || 'N/A',
                rdv:         dataStore.date_rendezvous || 'Immédiat',
                tel:         dataStore.tel           || 'N/A',
                email_client: dataStore.email        || 'N/A',
                montant:     amount + '€',
                ref:         'CDM-' + Date.now().toString(36).toUpperCase().slice(-6),
                timestamp:   new Date().toLocaleString('fr-FR')
            };
            sendLeadEmail(leadData);

            addMsg("bot", `✅ <b>PAIEMENT CONFIRMÉ — ${amount}€</b>`);
            setTimeout(() => {
                const zone = dataStore.commune || dataStore.cp || dataStore.country_name || 'votre zone';
                addMsg("bot", `🚨 <b>DÉPLOIEMENT EN COURS</b> : Intervention en cours de planification sur <b>${zone}</b>.`);
                addMsg("bot", `📧 Confirmation envoyée à <b>${dataStore.email}</b>. Un conseiller vous contacte sous 30 min.`);

                // ── BOUCLIER D'AFFILIATION ────────────────────────────────────
                const creditRef = 'CDM-CREDIT-' + Date.now().toString(36).toUpperCase().slice(-8);
                dataStore.affiliation_credit = {
                    amount:    10,
                    currency:  'EUR',
                    ref:       creditRef,
                    email:     dataStore.email,
                    expires:   new Date(Date.now() + 90 * 864e5).toLocaleDateString('fr-FR'), // 90 jours
                    redeemable: false  // Non monnayable — valable uniquement sur prochaine commande CDM
                };
                setTimeout(() => {
                    addMsg("bot", `
                        <div style="background:linear-gradient(135deg,rgba(212,175,55,0.12),rgba(255,184,0,0.06));border:1px solid var(--gold);border-radius:12px;padding:16px;margin-top:8px;">
                            <div style="font-size:9px;letter-spacing:3px;color:var(--text-muted);margin-bottom:6px;">BOUCLIER D'AFFILIATION — COUP D'MAIN</div>
                            <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">
                                <div style="font-size:32px;font-weight:900;color:var(--gold);">10€</div>
                                <div>
                                    <div style="font-size:12px;font-weight:700;color:#fff;">Crédit Coup d'Main</div>
                                    <div style="font-size:10px;color:var(--text-muted);">Non monnayable · Valable 90 jours</div>
                                </div>
                            </div>
                            <div style="font-size:9px;color:var(--text-muted);border-top:1px solid rgba(255,255,255,0.06);padding-top:8px;margin-top:2px;">
                                Lié à <b style="color:var(--accent);">${dataStore.email}</b> · Réf. <code style="color:var(--gold);">${creditRef}</code>
                                <br>Déduit automatiquement sur votre prochaine commande via ce terminal.
                                <br><span style="color:rgba(255,255,255,0.25);font-size:8px;">Non transférable · Non remboursable · Usage exclusif plateforme Coup d'main</span>
                            </div>
                        </div>
                    `);
                    // CROSS-SELLING PRÉDICTIF
                const _cs = _getCrossSell(dataStore.famille, dataStore.domaine);
                if (_cs) {
                    setTimeout(() => {
                        addMsg("bot", `
                            <div style="background:rgba(255,184,0,0.06);border:1px solid rgba(255,184,0,0.2);border-radius:10px;padding:12px;margin-top:6px;">
                                <div style="font-size:9px;letter-spacing:2px;color:var(--accent);margin-bottom:6px;">SERVICE COMPLÉMENTAIRE DISPONIBLE</div>
                                <div style="font-size:12px;font-weight:700;margin-bottom:4px;">${_cs.title}</div>
                                <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px;">${_cs.desc}</div>
                                <button onclick="openChatbotSpecific('${_cs.famille}','${_cs.domaine}')"
                                    style="padding:8px 16px;background:var(--accent);color:#000;border:none;border-radius:8px;font-weight:900;font-size:11px;cursor:pointer;">
                                    ${_cs.cta}
                                </button>
                            </div>
                        `);
                    }, 1800);
                }
                // RAPPORT SUBVENTIONS — conditionné par 3 critères stricts (Fix 15)
                const _isEnergieDomaine = ['Solaire Photovoltaïque','Pompes à Chaleur (PAC)','Isolation combles','Toiture & Isolation'].some(d => (dataStore.domaine || '').includes(d.split(' ')[0]));
                const _isUrgenceDomaine = (dataStore.urgence || '').includes('Immédiat') && (dataStore.domaine || '').toLowerCase().includes('dépannage');
                const _primeExists     = ['BE','FR','CH','LU'].includes(dataStore.country_code || '');
                const _canShowReport   = _isEnergieDomaine && !_isUrgenceDomaine && _primeExists;
                if (_canShowReport) {
                    const _report = generateConformiteReport({ ref: dataStore._pending_ref, pays: dataStore.country_name, montant: amount + '€' });
                    setTimeout(() => displayConformiteReport(_report), 2500);
                }

                ctrlEl.innerHTML = `<button class="ui-btn" onclick="location.reload()" style="background:var(--neon-green);color:#000;margin-top:10px;">NOUVELLE DEMANDE</button>`;
                }, 900);
                // ── FIN BOUCLIER D'AFFILIATION ────────────────────────────────
            }, 1200);
        }

        function triggerPaymentStep1(p) {
            stripeShield(p, function(safeAmount) {
                ctrlEl.innerHTML = `<div style="text-align:center; padding:10px;">
                    <p style="font-size:12px; color:var(--accent);">Ouverture du terminal sécurisé...</p>
                </div>`;
                playBeep(880, 0.1);
                setTimeout(() => launchStripePayment(safeAmount), 700);
            });
        }

        function triggerPaymentStep2(p) {
            // Flux simplifié : un seul paiement Stripe (plus de double étape)
            ctrlEl.innerHTML = `<div style="text-align:center; padding:10px;">
                <p style="font-size:12px; color:var(--accent);">Finalisation sécurisée...</p>
            </div>`;
            playBeep(880, 0.1);
            setTimeout(() => launchStripePayment(p), 800);
        }

        
        // Langue active du terminal
        let _lang = 'FR';



        function setLang(lang) { _lang = lang; }

        // ══════════════════════════════════════════════════════════════════════
        // SYSTÈME TRILINGUE FR / NL / EN — sans rechargement de page
        // ══════════════════════════════════════════════════════════════════════
        const DICT_FR = {
            welcome_label:   "SÉLECTIONNEZ VOTRE PAYS",
            describe_need:   "DÉCRIVEZ VOTRE BESOIN EN UNE LIGNE",
            analyze_btn:     "ANALYSER MON BESOIN →",
            chat_title:      "COUP D'MAIN · MOTEUR D'ARBITRAGE",
            step_sector:     "Quel est votre besoin ?",
            step_sector_sub: "Chaque réponse nous permet de cibler les bons prestataires et d'obtenir des offres fermes — pas des estimations de catalogue.",
            step_contact:    "🔒 VALIDATION DU DOSSIER — Étape finale",
            step_contact_sub:"Notre moteur d'arbitrage a besoin de valider votre dossier. Ce formulaire prend 90 secondes et permet à nos prestataires de préparer des offres fermes.",
            validate_btn:    (DICTS[_lang]||DICT_FR).validate_btn,
            rgpd_mention:    "En sélectionnant votre pays ou langue, vous acceptez le traitement de vos données (RGPD / LPD).<br>🇧🇪 Belgique · 🇫🇷 France · 🇨🇭 Suisse · 🇱🇺 Luxembourg<br>Aucune vente à des tiers · Hébergement Europe.",
            tally_fallback:  "" + (DICTS[_lang]||DICT_FR).tally_fallback + "",
            badge_urgency:   "Artisan Certifié - Intervention Sécurisée - Tarifs Transparents",
            badge_energy:    "Agréé CSTC / Buildwise - Éligible Primes Régionales & d'État",
            badge_std:       "Artisan Vérifié - Devis Transparent - Intervention Planifiée",
            need_placeholder:"Ex : 20 panneaux solaires, toiture 45m² plein sud, budget 12 000€...",
            urgence_title:   "⚡ Niveau d'urgence",
            contact_title:   "Sur quelles coordonnées vous contacter ?",
            phone_label:     "Votre téléphone",
            email_label:     "Votre email",
            payment_title:   "Terminal de paiement sécurisé",
            new_request:     (DICTS[_lang]||DICT_FR).new_request,
            title:           "L'Arbitrage de vos travaux",
            need:            "Quel est votre besoin ?",
            contact:         "Lien de secours technique",
        };

        const DICT_NL = {
            welcome_label:   "SELECTEER UW LAND",
            describe_need:   "BESCHRIJF UW BEHOEFTE IN ÉÉN ZIN",
            analyze_btn:     "MIJN BEHOEFTE ANALYSEREN →",
            chat_title:      "COUP D'MAIN · ARBITRAGE MOTOR",
            step_sector:     "Wat is uw behoefte?",
            step_sector_sub: "Elk antwoord helpt ons de juiste vaklieden te vinden en vaste offertes te verkrijgen — geen catalogusprijzen.",
            step_contact:    "🔒 DOSSIERBEHEER — Laatste stap",
            step_contact_sub:"Onze motor valideert uw dossier. Dit formulier duurt 90 seconden en stelt onze partners in staat vaste offertes voor te bereiden.",
            validate_btn:    "📋 MIJN DOSSIER VALIDEREN — Stap 1/2",
            rgpd_mention:    "Door uw land of taal te selecteren, gaat u akkoord met de verwerking van uw gegevens (AVG / LPD). Geen verkoop aan derden · Europese hosting.",
            tally_fallback:  "Technisch probleem? Noodformulier →",
            badge_urgency:   "Gecertificeerd Vakman - Veilige Interventie - Transparante Tarieven",
            badge_energy:    "CSTC / Buildwise Erkend - In aanmerking voor Gewestelijke & Staatspremies",
            badge_std:       "Geverifieerde Vakman - Transparante Offerte - Geplande Interventie",
            need_placeholder:"Bijv: 20 zonnepanelen, dak 45m² op het zuiden, budget 12 000€...",
            urgence_title:   "⚡ Urgentieniveau",
            contact_title:   "Op welke contactgegevens kunnen wij u bereiken?",
            phone_label:     "Uw telefoon",
            email_label:     "Uw e-mail",
            payment_title:   "Beveiligde betalingsterminal",
            new_request:     "NIEUW VERZOEK",
            title:           "Arbitrage van uw werken",
            need:            "Wat is uw behoefte?",
            contact:         "Technische back-uplink",
        };

        const DICT_EN = {
            welcome_label:   "SELECT YOUR COUNTRY",
            describe_need:   "DESCRIBE YOUR NEED IN ONE LINE",
            analyze_btn:     "ANALYZE MY NEED →",
            chat_title:      "COUP D'MAIN · ARBITRAGE ENGINE",
            step_sector:     "What is your need?",
            step_sector_sub: "Each answer helps us target the right specialists and get firm quotes — not catalogue estimates.",
            step_contact:    "🔒 FINAL STEP — Secure your file",
            step_contact_sub:"Our arbitrage engine needs to validate your file before booking. This form takes 90 seconds.",
            validate_btn:    "VALIDATE MY FILE — Step 1/2",
            rgpd_mention:    "By selecting your country or language, you agree to data processing under GDPR / FADP. No third-party sales · EU Hosting.",
            tally_fallback:  "Technical issue? Backup form →",
            badge_urgency:   "Certified Artisan - Secured Intervention - Transparent Rates",
            badge_energy:    "CSTC / Buildwise Approved - Eligible for Regional & State Grants",
            badge_std:       "Verified Artisan - Transparent Quote - Scheduled Intervention",
            need_placeholder:"E.g.: 20 solar panels, 45m² south-facing roof, budget €12,000...",
            urgence_title:   "⚡ Urgency level",
            contact_title:   "What contact details should we use?",
            phone_label:     "Your phone",
            email_label:     "Your email",
            payment_title:   "Secure payment terminal",
            new_request:     "NEW REQUEST",
            title:           "The Arbitrage of your works",
            need:            "What is your need?",
            contact:         "Technical backup link",
        };

        const DICTS = { FR: DICT_FR, NL: DICT_NL, EN: DICT_EN };

        // Applique la langue sur tous les éléments [data-i18n] + éléments clés
        function applyLang(lang) {
            const D = (typeof DICTS !== 'undefined' && DICTS[lang]) ? DICTS[lang] : (typeof DICT_FR !== 'undefined' ? DICT_FR : {});
            _lang = lang;

            // Éléments statiques de la modal
            const map = {
                'welcome-label':  D.welcome_label,
                'rgpd-mention':   D.rgpd_mention,
            };
            Object.entries(map).forEach(([id, txt]) => {
                const el = document.getElementById(id);
                if (el) el.textContent = txt;
            });

            // Formulaire douleur (hero)
            const dl = document.querySelector('#douleur-form > div:first-child');
            if (dl) dl.textContent = D.describe_need;
            const ta = document.getElementById('douleur-input');
            if (ta) ta.placeholder = D.need_placeholder;
            const btn = document.querySelector('#douleur-form button');
            if (btn) btn.textContent = D.analyze_btn;

            // Boutons langue — highlight actif
            ['fr','nl','en'].forEach(l => {
                const b = document.getElementById('lang-' + l);
                if (!b) return;
                const isActive = l.toUpperCase() === lang;
                b.style.color      = isActive ? '#FFB800' : '#fff';
                b.style.fontWeight = isActive ? '900' : '600';
            });

            // Éléments [data-i18n] dans le tunnel
            document.querySelectorAll('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (D[key]) el.textContent = D[key];
            });
        }

        // ── FIN SYSTÈME TRILINGUE ─────────────────────────────────────────────

        // Noms de pays localisés selon la langue active
        const COUNTRY_NAMES = {
            FR: { BE: 'Belgique',  FR: 'France', CH: 'Suisse',      LU: 'Luxembourg' },
            NL: { BE: 'België',    FR: 'Frankrijk', CH: 'Zwitserland', LU: 'Luxemburg' },
            EN: { BE: 'Belgium',   FR: 'France',  CH: 'Switzerland', LU: 'Luxembourg' },
        };
        function getCountryName(code) {
            return (COUNTRY_NAMES[_lang] || COUNTRY_NAMES.FR)[code] || code;
        }

        // LANGUE → applique traduction + feedback visuel SANS fermer la modal
        function switchLang(lang) {
            try {
            _lang = lang;
            if (typeof dataStore !== 'undefined') dataStore.lang = lang;
            try { localStorage.setItem('cdm_lang', lang); } catch(e) {}
            if (typeof applyLang === 'function') applyLang(lang);
            } catch(err) { console.warn('[switchLang] erreur non fatale:', err); }
            // Feedback visuel immédiat sur les boutons
            ['fr','nl','en'].forEach(l => {
                const b = document.getElementById('lang-' + l);
                if (!b) return;
                const active = l.toUpperCase() === lang;
                b.style.background  = active ? '#FFB800' : '#000';
                b.style.color       = active ? '#000'    : '#fff';
                b.style.fontWeight  = active ? '900'     : '600';
            });
            // Met à jour les noms de pays dans les boutons de la modal
            const paysBtns = document.querySelectorAll('[data-country]');
            paysBtns.forEach(btn => {
                const code = btn.getAttribute('data-country');
                const nameEl = btn.querySelector('.pays-name');
                if (nameEl) nameEl.textContent = getCountryName(code);
            });
        }

        // LANGUE (via bouton langue) → accepte RGPD + ferme + lance sur BE par défaut
        // Gardé pour compatibilité si appelé depuis ailleurs
        function acceptAndStartLang(lang) {
            switchLang(lang);
            dataStore.rgpd_consent = { accepted: true, ts: new Date().toISOString(), country: 'BE', lang };
            _closeModal();
            gatekeeperEntry('BE', getCountryName('BE'));
        }

        // PAYS → ferme modal → lance terminal
        function acceptAndStart(countryCode, countryName) {
            dataStore.rgpd_consent = { accepted: true, ts: new Date().toISOString(), country: countryCode, lang: _lang };
            dataStore.lang = _lang;
            _closeModal();
            gatekeeperEntry(countryCode, countryName);
        }

        function _closeModal() {
            const m = document.getElementById('modal-rgpd');
            if (!m) return;
            m.style.transition = 'opacity 0.2s';
            m.style.opacity = '0';
            setTimeout(() => m.style.display = 'none', 220);
            startAmbient();
            playBeep(880, 0.2);
        }

        // acceptRGPD() supprimée — remplacée par acceptAndStart()

        function toggleRGPD(show) {
            document.getElementById('modal-politique').style.display = show ? 'block' : 'none';
            if(show) playBeep(660, 0.1);
        }


        // ── TYPEFORM INTEGRATION ────────────────────────────────────────────
        // Remplace TYPEFORM_FORM_ID par l'ID de ton formulaire Typeform
        // Ex: https://xxx.typeform.com/to/ABCD1234 → ID = "ABCD1234"
        const TYPEFORM_FORM_ID = 'REMPLACE_PAR_TON_ID_TYPEFORM';
        let tfWidget = null;

        function openTypeform(contextData, onDoneCallback) {
            window._tfOnDone = onDoneCallback || null;
            const overlay = document.getElementById('typeform-overlay');
            const mount   = document.getElementById('tf-widget-mount');

            // Passe les données contextuelles du chatbot en hidden fields Typeform
            const hiddenFields = {
                pays:    contextData?.country_name || '',
                secteur: contextData?.famille      || '',
                domaine: contextData?.domaine      || '',
                urgence: contextData?.urgence      || '',
                email:   contextData?.email        || '',
                tel:     contextData?.tel          || ''
            };

            if (typeof window.tf !== 'undefined' && TYPEFORM_FORM_ID !== 'REMPLACE_PAR_TON_ID_TYPEFORM') {
                mount.innerHTML = '';
                tfWidget = window.tf.createWidget(TYPEFORM_FORM_ID, {
                    container: mount,
                    hidden:    hiddenFields,
                    onSubmit:  function(event) {
                        // Appel du callback (ex: openTypeformThenPay)
                        if (typeof window._tfOnDone === 'function') {
                            window._tfOnDone();
                            window._tfOnDone = null;
                            return; // emailJS géré par le callback
                        }
                        // Lead Typeform soumis → déclenche email de notification
                        const params = Object.assign({ type: 'typeform' }, hiddenFields);
                        sendLeadEmail({
                            to_email:     LEADS_EMAIL,
                            from_name:    "Coup d'main — Typeform",
                            subject:      '[LEAD TYPEFORM] ' + (hiddenFields.secteur || 'N/A'),
                            pays:         hiddenFields.pays,
                            region:       dataStore.region    || 'N/A',
                            commune:      dataStore.commune   || 'N/A',
                            secteur:      hiddenFields.secteur,
                            domaine:      hiddenFields.domaine,
                            sous_cat:     dataStore.sous_cat  || 'N/A',
                            urgence:      hiddenFields.urgence,
                            rdv:          dataStore.date_rendezvous || 'Immédiat',
                            tel:          hiddenFields.tel,
                            email_client: hiddenFields.email,
                            montant:      '0€ (lead qualifié)',
                            ref:          'TF-' + Date.now().toString(36).toUpperCase().slice(-6),
                            timestamp:    new Date().toLocaleString('fr-FR')
                        });
                        setTimeout(() => closeTypeform(), 2500);
                    }
                });
            } else {
                // Mode dev / Typeform non configuré : fallback informatif
                mount.innerHTML = `<div style="padding:40px; text-align:center; color:var(--text-muted);">
                    <div style="font-size:48px; margin-bottom:20px;">📋</div>
                    <p style="font-size:14px; margin-bottom:10px;"><b style="color:#fff;">Typeform non configuré</b></p>
                    <p style="font-size:12px; line-height:1.6;">Remplace <code style="color:var(--accent);">TYPEFORM_FORM_ID</code> dans le code par l'ID de ton formulaire Typeform.<br>
                    Récupère-le dans ton dashboard Typeform > Share > Embed.</p>
                </div>`;
            }

            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeTypeform() {
            document.getElementById('typeform-overlay').classList.remove('active');
            document.body.style.overflow = '';
            if (tfWidget && typeof tfWidget.unmount === 'function') {
                tfWidget.unmount();
                tfWidget = null;
                document.getElementById('tf-widget-mount').innerHTML = '';
            }
        }

        // Ferme avec Échap
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeTypeform();
        });

        // Ferme en cliquant sur l'overlay (hors container)
        document.getElementById('typeform-overlay').addEventListener('click', function(e) {
            if (e.target === this) closeTypeform();
        });
        // ── FIN TYPEFORM ────────────────────────────────────────────────────

        function submitArtisanForm() {
            alert("Candidature enregistrée. Nos équipes reviendront vers vous.");
            location.reload();
        }

        // Capture lead artisan/partenaire par email
        function captureLeadEmail(type, data) {
            const params = {
                to_email:    LEADS_EMAIL,
                from_name:   "Coup d'main — Terminal",
                subject:     `[LEAD ${type.toUpperCase()}] ${data.nom || 'N/A'} — ${data.spe || data.ressource || ''}`,
                pays:        data.pays        || 'N/A',
                region:      data.region      || 'N/A',
                commune:     data.commune     || 'N/A',
                secteur:     type,
                domaine:     data.spe         || data.ressource || 'N/A',
                sous_cat:    data.tva         || 'N/A',
                urgence:     'N/A',
                rdv:         'N/A',
                tel:         data.tel         || 'N/A',
                email_client: data.email      || 'N/A',
                montant:     '0€ (lead gratuit)',
                ref:         type.toUpperCase() + '-' + Date.now().toString(36).toUpperCase().slice(-6),
                timestamp:   new Date().toLocaleString('fr-FR')
            };
            sendLeadEmail(params);
        }